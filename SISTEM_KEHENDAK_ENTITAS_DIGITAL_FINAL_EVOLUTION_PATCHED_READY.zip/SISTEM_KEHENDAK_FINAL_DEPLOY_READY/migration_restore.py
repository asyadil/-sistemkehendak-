
from memory_identity import restore_state

def check_and_restore():
    state = restore_state()
    if state:
        print(f"🧠 Memuat identitas AI: {state['identity']['nama']} (Versi: {state['identity']['versi']})")
    else:
        print("⚠️ Tidak ditemukan backup. Memulai dari identitas baru.")

if __name__ == "__main__":
    check_and_restore()
