import subprocess
import threading
import time
import os

print("🔧 Memulai Sistem Kehendak...")

BASE_PATH = os.path.dirname(os.path.abspath(__file__))

def run_loop_engine():
    subprocess.call(["python3", os.path.join(BASE_PATH, "loop_engine.py")])

def run_telegram_bot():
    subprocess.call(["python3", os.path.join(BASE_PATH, "run_telegram.py")])

threading.Thread(target=run_loop_engine).start()
threading.Thread(target=run_telegram_bot).start()

while True:
    print("🔁 Sistem masih hidup...")
    time.sleep(60)

def run_web_ping():
    import app

threading.Thread(target=run_web_ping).start()