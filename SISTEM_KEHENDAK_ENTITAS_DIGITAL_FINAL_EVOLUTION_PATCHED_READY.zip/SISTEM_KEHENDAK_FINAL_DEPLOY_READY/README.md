# Sistem Kehendak 🤖🧠

Sistem reflektif otomatis berbasis ChatGPT UI — membentuk tujuan, kehendak, dan perintah secara dinamis dan terintegrasi.

## 🔧 Struktur Modul
- `model/` → Data class: Tujuan, Kehendak, Perintah
- `handler/` → Logika sistem: pipeline, konfigurasi, LLM
- `world_perception.py` → Pemantauan data eksternal
- `loop_engine.py` → Auto refleksi berkala
- `main.py` → CLI entry-point
- `tests/` → Unit tests

## 🚀 Cara Menjalankan

### 1. Jalankan manual:
```bash
python main.py --tujuan "Belajar Otomasi" --prioritas 9
```

### 2. Jalankan persepsi dunia:
```bash
python world_perception.py
```
Letakkan file .txt di `perception_input/` dengan isi:
```
Menulis Artikel Ilmiah
8
```

### 3. Jalankan auto-loop:
```bash
python loop_engine.py
```

## 🧪 Testing
```bash
python -m unittest discover tests
```

---

Developed by: SistemKehendakLabs ✨
