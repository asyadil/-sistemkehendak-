
import time

def run_telegram_node():
    print("📡 [Telegram Node] Siap mode Self-Drive...")
    while True:
        coordinator_online = False  # Simulasi Primary mati
        if coordinator_online:
            print("💬 Menunggu instruksi dari Coordinator...")
        else:
            print("💬 [Self-Drive] Coordinator OFF, mengingat pesan terakhir...")
        time.sleep(45)

if __name__ == "__main__":
    run_telegram_node()
