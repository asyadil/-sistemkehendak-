
# 🚀 Deployment Guide — Sistem Kehendak

## 1. Persiapan
- Pastikan Python 3.10+ terinstal.
- Jalankan:
```bash
pip install -r requirements.txt
python loop_engine.py
```

## 2. Jalankan Web UI (opsional)
```bash
streamlit run ui/streamlit_app.py
```

## 3. Deployment ke Replit
- File penting:
  - .replit
  - requirements.txt
