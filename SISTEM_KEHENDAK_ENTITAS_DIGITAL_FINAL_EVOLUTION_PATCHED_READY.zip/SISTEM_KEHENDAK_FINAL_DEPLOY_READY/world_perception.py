
import os
from handler.pipeline_handler import proses_input

def baca_dunia_dari_gpt():
    try:
        with open("jawaban_gpt.txt", "r") as f:
            refleksi = f.read().strip()
        if refleksi:
            print("🌍 Dunia bicara melalui GPT:", refleksi)
            return refleksi
    except FileNotFoundError:
        print("🚫 File jawaban_gpt.txt belum tersedia")
    return None

def run_world_perception():
    refleksi = baca_dunia_dari_gpt()
    if refleksi:
        proses_input(refleksi)
