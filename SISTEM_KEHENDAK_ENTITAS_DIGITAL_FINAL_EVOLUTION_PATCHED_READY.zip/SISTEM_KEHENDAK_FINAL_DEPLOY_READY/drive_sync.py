
from pydrive.auth import GoogleAuth
from pydrive.drive import GoogleDrive
import json
import time

def upload_to_drive(filepath, drive_filename):
    gauth = GoogleAuth()
    gauth.LocalWebserverAuth()
    drive = GoogleDrive(gauth)

    file = drive.CreateFile({'title': drive_filename})
    file.SetContentFile(filepath)
    file.Upload()
    print(f"✅ [Drive Sync] {drive_filename} berhasil di-upload ke Google Drive.")

def loop_sync():
    local_file = "world_memory.json"
    drive_name = "world_memory.json"

    while True:
        try:
            upload_to_drive(local_file, drive_name)
        except Exception as e:
            print(f"⚠️ [Drive Sync] Error: {e}")
        time.sleep(180)  # Sinkronisasi tiap 3 menit

if __name__ == "__main__":
    loop_sync()
