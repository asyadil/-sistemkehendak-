
import time

def run_search_node():
    print("🌍 [Search Node] Siap mode Self-Drive...")
    while True:
        # Dummy status koordinasi
        coordinator_online = False  # Simulasi Primary mati
        if coordinator_online:
            print("🔍 Menunggu tugas dari Coordinator...")
        else:
            print("🧠 [Self-Drive] Coordinator tidak terdeteksi, melakukan pencarian default...")
        time.sleep(45)

if __name__ == "__main__":
    run_search_node()
