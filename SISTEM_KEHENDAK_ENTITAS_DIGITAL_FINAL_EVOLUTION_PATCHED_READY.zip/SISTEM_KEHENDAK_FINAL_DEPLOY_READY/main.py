import argparse
from handler.pipeline_handler import proses_input

def main():
    parser = argparse.ArgumentParser(description="Sistem Kehendak CLI")
    parser.add_argument("--tujuan", type=str, help="Nama tujuan", default="Belajar AI")
    parser.add_argument("--prioritas", type=int, help="Nilai prioritas (1-10)", default=5)
    args = parser.parse_args()

    # Panggil pipeline dengan argumen
    proses_input(vars(args))

if __name__ == "__main__":
    main()
