class Perintah:
    def __init__(self, kehendak):
        self.kehendak = kehendak
        self.aksi = self.buat_aksi_dari_kehendak()
        self.status = "belum dijalankan"

    def buat_aksi_dari_kehendak(self):
        # Dummy aksi berbasis nama tujuan
        return f"Laksanakan aksi untuk tujuan: {self.kehendak.tujuan.nama}"

    def jalankan(self):
        self.status = "sudah dijalankan"
        return f"Menjalankan: {self.aksi}"

    def is_selesai(self):
        return self.status == "sudah dijalankan"
