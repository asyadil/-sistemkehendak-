class Kehendak:
    def __init__(self, tujuan):
        self.tujuan = tujuan
        self.status = "belum diwujudkan"
        self.intensitas = self.hitung_intensitas()

    def hitung_intensitas(self):
        # Sementara intensitas diturunkan dari prioritas tujuan
        return self.tujuan.prioritas * 10

    def wujudkan(self):
        self.status = "terwujud"

    def is_terwujud(self):
        return self.status == "terwujud"

    def deskripsi(self):
        return f"Kehendak untuk mewujudkan tujuan '{self.tujuan.nama}' dengan intensitas {self.intensitas}"
