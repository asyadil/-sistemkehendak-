""" Modul __init__.py (persepsi) """
# init persepsi