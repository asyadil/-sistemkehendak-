""" Modul __init__.py (memori) """
# init memori