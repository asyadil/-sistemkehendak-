""" Modul __init__.py (emosi) """
# init emosi