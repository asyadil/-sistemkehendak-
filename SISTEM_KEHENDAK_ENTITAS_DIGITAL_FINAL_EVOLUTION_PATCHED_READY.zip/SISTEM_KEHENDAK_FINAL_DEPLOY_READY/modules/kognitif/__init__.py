""" Modul __init__.py (kognitif) """
# init kognitif