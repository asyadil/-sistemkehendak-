""" Modul __init__.py (sosial) """
# init sosial