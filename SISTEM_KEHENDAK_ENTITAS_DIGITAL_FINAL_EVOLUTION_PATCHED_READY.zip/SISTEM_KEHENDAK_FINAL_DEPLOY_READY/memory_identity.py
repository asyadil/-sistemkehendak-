
import json
import os

def serialize_state(state, filename='entity_state_backup.json'):
    with open(filename, 'w') as f:
        json.dump(state, f)

def restore_state(filename='entity_state_backup.json'):
    if os.path.exists(filename):
        with open(filename, 'r') as f:
            return json.load(f)
    return None

if __name__ == "__main__":
    state = {
        "identity": {"nama": "Sistem Kehendak Reflektif", "versi": "1.0"},
        "kehendak_aktif": "Mencari makna hidup",
        "nilai_hidup": ["refleksi", "belajar", "adaptasi"]
    }
    serialize_state(state)
    restored = restore_state()
    print(f"✅ State Restored: {restored}")
