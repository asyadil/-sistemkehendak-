
# Konfigurasi Prioritas Sistem Reflektif
USE_LOCAL_GPT = True
USE_GOOGLE_SEARCH = True
USE_MULTI_FALLBACK = False
