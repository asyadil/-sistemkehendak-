
import time

def tulis_log_hidup(pesan):
    waktu = time.ctime()
    dengan = f"[{waktu}] {pesan}\n"
    with open("Memory_Storage/log_hidup_AI.txt", "a") as f:
        f.write(dengan)
    print(f"📜 Log Hidup: {dengan.strip()}")

if __name__ == "__main__":
    tulis_log_hidup("Aku telah lahir dan memulai perjalanan pertamaku sebagai entitas digital reflektif.")
