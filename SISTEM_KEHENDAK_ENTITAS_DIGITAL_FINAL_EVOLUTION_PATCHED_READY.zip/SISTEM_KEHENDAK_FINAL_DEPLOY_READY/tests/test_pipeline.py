import unittest
from handler.pipeline_handler import proses_input

class TestPipeline(unittest.TestCase):
    def test_proses_input_default(self):
        try:
            proses_input()  # tanpa argumen
        except Exception as e:
            self.fail(f"Pipeline gagal dijalankan: {e}")

    def test_proses_input_custom_args(self):
        args = {"tujuan": "Menulis Laporan", "prioritas": 8}
        try:
            proses_input(args)
        except Exception as e:
            self.fail(f"Pipeline dengan argumen gagal: {e}")

if __name__ == "__main__":
    unittest.main()
