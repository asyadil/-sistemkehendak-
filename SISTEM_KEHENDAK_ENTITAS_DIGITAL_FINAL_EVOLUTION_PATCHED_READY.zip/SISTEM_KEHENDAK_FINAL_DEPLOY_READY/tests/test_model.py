import unittest
from model.tujuan import Tujuan
from model.kehendak import Kehendak
from model.perintah import Perintah

class TestModel(unittest.TestCase):
    def test_tujuan(self):
        t = Tujuan("Makan", 7)
        self.assertEqual(t.nama, "Makan")
        self.assertEqual(t.prioritas, 7)

    def test_kehendak(self):
        t = Tujuan("Tidur", 5)
        k = Kehendak(t)
        self.assertEqual(k.tujuan.nama, "Tidur")
        self.assertEqual(k.status, "belum diwujudkan")
        self.assertTrue(k.intensitas > 0)
        k.wujudkan()
        self.assertTrue(k.is_terwujud())

    def test_perintah(self):
        t = Tujuan("Minum", 6)
        k = Kehendak(t)
        p = Perintah(k)
        self.assertIn("Minum", p.aksi)
        self.assertEqual(p.status, "belum dijalankan")
        p.jalankan()
        self.assertTrue(p.is_selesai())

if __name__ == "__main__":
    unittest.main()
