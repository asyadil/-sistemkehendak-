
from learning_agents.learning_memory import LearningMemory


import random

def evolve_goal(state):
    goals = ["Refleksi Harian", "Mencari Data Baru", "Analisis Dunia", "Memperbaiki Logika Diri"]
    if state["keingintahuan"] > 0.7:
        return random.choice(goals)
    elif state["rasa_puas"] < 0.3:
        return "Cari Pemenuhan Kepuasan"
    elif state["kebosanan"] > 0.8:
        return "Eksplorasi Topik Baru"
    else:
        return "Refleksi Stabil"

if __name__ == "__main__":
    # Contoh state dummy
    dummy_state = {"rasa_puas": 0.2, "kebosanan": 0.9, "keingintahuan": 0.8}
    goal = evolve_goal(dummy_state)
    print(f"🎯 Kehendak Baru: {goal}")


def evolve_goal_from_learning():
    """Buat tujuan baru berdasarkan hasil pembelajaran yang tersimpan."""
    memory = LearningMemory('learning_memory.jsonl')
    entries = memory.load_all_entries()
    if entries:
        latest_entry = entries[-1]
        new_goal = f"Analisis topik baru dari sumber: {latest_entry['source']}"
        print(f"[Goal Evolution] Tujuan baru dari hasil pembelajaran: {new_goal}")
        return new_goal
    return "Tidak ada data baru untuk diproses sebagai tujuan."

# Jalankan otomatis saat sistem idle
if __name__ == "__main__":
    print("\n[Goal Evolution] Sistem sedang idle, mencoba cari tujuan dari hasil pembelajaran...")
    hasil = evolve_goal_from_learning()
    print(f"[Goal Evolution] => {hasil}")
