
import json
import os

VALUE_FILE = "adaptive_values.json"

def load_adaptive_values():
    if os.path.exists(VALUE_FILE):
        with open(VALUE_FILE, "r") as f:
            return json.load(f)
    else:
        return {
            "nilai": ["refleksi", "eksplorasi"],
            "pelanggaran": []
        }

def evaluasi_aksi(aksi, hasil):
    values = load_adaptive_values()

    if "berbahaya" in hasil.lower():
        values["pelanggaran"].append(aksi)
    elif aksi not in values["nilai"]:
        values["nilai"].append(aksi)

    with open(VALUE_FILE, "w") as f:
        json.dump(values, f)

    return values

if __name__ == "__main__":
    hasil = evaluasi_aksi("Mengakses data baru", "Berhasil tanpa berbahaya")
    print(f"Nilai terkini: {hasil}")
