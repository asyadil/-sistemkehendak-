
import json
import os
from datetime import datetime

LOG_FILE = "memory/activity_log.jsonl"

def log_aktivitas(input_user, tujuan, kehendak, perintah, evaluasi=None):
    entry = {
        "timestamp": datetime.now().isoformat(),
        "input": input_user,
        "tujuan": tujuan,
        "kehendak": kehendak,
        "perintah": perintah,
        "evaluasi": evaluasi or []
    }
    with open(LOG_FILE, "a") as f:
        f.write(json.dumps(entry) + "\n")

def baca_log(n=10):
    try:
        with open(LOG_FILE, "r") as f:
            lines = f.readlines()
            return [json.loads(line) for line in lines][-n:]
    except FileNotFoundError:
        return []
