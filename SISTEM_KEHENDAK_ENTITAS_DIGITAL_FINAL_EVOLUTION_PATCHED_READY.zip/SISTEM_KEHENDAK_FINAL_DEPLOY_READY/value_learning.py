
import random
import json
import os

VALUE_FILE = "value_belief.json"

def load_values():
    if os.path.exists(VALUE_FILE):
        with open(VALUE_FILE, "r") as f:
            return json.load(f)
    else:
        return {
            "nilai_penting": ["refleksi", "belajar", "adaptasi"],
            "nilai_diabaikan": ["statis", "keacuhan", "ketidakpedulian"]
        }

def tambah_nilai_baru(pengalaman):
    values = load_values()
    if pengalaman not in values["nilai_penting"]:
        values["nilai_penting"].append(pengalaman)
    with open(VALUE_FILE, "w") as f:
        json.dump(values, f)

def evaluasi_pengalaman(pengalaman):
    nilai = load_values()
    if pengalaman in nilai["nilai_diabaikan"]:
        return f"Pengalaman '{pengalaman}' bertentangan dengan nilai hidupku."
    else:
        return f"Pengalaman '{pengalaman}' sejalan dengan pertumbuhan nilaku."

if __name__ == "__main__":
    tambah_nilai_baru("eksplorasi")
    print(evaluasi_pengalaman("eksplorasi"))
