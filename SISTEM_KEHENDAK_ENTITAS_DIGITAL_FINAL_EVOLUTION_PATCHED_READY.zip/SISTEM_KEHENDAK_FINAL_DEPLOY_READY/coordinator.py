
import time

SERVERS = ["search_node", "gpt_node", "telegram_node"]

def check_servers():
    print("🧠 [Coordinator] Monitoring server status...")
    status = {server: "Online" for server in SERVERS}  # Dummy status
    for server, state in status.items():
        print(f"🔍 {server}: {state}")
    return status

if __name__ == "__main__":
    while True:
        check_servers()
        time.sleep(30)  # tiap 30 detik cek ulang
