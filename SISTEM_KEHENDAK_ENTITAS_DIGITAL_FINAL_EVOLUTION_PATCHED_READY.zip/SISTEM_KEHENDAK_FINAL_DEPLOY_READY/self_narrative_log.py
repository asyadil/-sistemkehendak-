
import time

def write_narrative(event):
    with open("self_narrative.log", "a") as log:
        log.write(f"[{time.ctime()}] {event}\n")

if __name__ == "__main__":
    write_narrative("Hari ini aku mengalami proses refleksi yang menarik.")
    write_narrative("Aku merasa kebosanan meningkat, dan ingin mengeksplor hal baru.")
