""" Modul Self Evolution: Mengaktifkan atau menonaktifkan modul berdasarkan evaluasi. """

from core.modul_base import ModulBase
from datetime import datetime

class ModulSelfEvolution(ModulBase):
    def __init__(self):
        self.log_file = "data/self_evolution_log.txt"
        self.threshold_nonaktif = 0.3

    def evaluasi_evolusi(self, modul_list):
        hasil = []
        for modul in modul_list:
            skor = getattr(modul, "skor_evaluasi", 0.5)
            if skor < self.threshold_nonaktif:
                modul.aktif = False
                hasil.append(f"{modul.__class__.__name__} → DINONAKTIFKAN (skor={skor:.2f})")
            else:
                modul.aktif = True
                hasil.append(f"{modul.__class__.__name__} → AKTIF (skor={skor:.2f})")
        return hasil

    def jalankan(self):
        try:
            from core.system_manager import modul_list
            hasil = self.evaluasi_evolusi(modul_list)
            with open(self.log_file, "a", encoding="utf-8") as f:
                for h in hasil:
                    f.write(f"[{datetime.now()}] {h}\n")
        except Exception as e:
            print(f"[ERROR-Evolusi] {e}")
