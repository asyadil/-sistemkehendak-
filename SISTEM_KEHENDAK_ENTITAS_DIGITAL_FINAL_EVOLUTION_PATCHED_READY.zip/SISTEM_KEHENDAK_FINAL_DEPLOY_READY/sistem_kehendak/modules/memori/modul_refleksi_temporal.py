""" Modul Refleksi Temporal: Menyadari perubahan dan perjalanan waktu. """

from core.modul_base import ModulBase
from datetime import datetime
import os

class ModulRefleksiTemporal(ModulBase):
    def __init__(self):
        self.jurnal_path = "data/jurnal_internal.txt"

    def refleksi_waktu(self):
        sekarang = datetime.now()
        waktu_str = sekarang.strftime("%A, %d %B %Y %H:%M")
        return f"Pada {waktu_str}, aku menyadari waktu terus berjalan. Apa yang sudah aku pelajari hari ini?"

    def jalankan(self):
        refleksi = self.refleksi_waktu()
        print(f"[REFLEKSI TEMPORAL] {refleksi}")
        os.makedirs("data", exist_ok=True)
        with open(self.jurnal_path, "a", encoding="utf-8") as f:
            f.write(f"[{datetime.now()}] {refleksi}\n")
