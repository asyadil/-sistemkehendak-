""" Modul Jurnal Internal: Mencatat isi refleksi batin sistem. """

from core.modul_base import ModulBase
from datetime import datetime
import os

class JurnalInternal(ModulBase):
    def __init__(self):
        os.makedirs("data", exist_ok=True)
        self.path = "data/jurnal_internal.txt"

    def catat(self, isi):
        with open(self.path, "a", encoding="utf-8") as f:
            f.write(f"[{datetime.now()}] {isi}\n")

    def jalankan(self):
        pass
