""" Modul Pemicu Aktif: Memicu aktivitas sistem saat idle terlalu lama. """

from core.modul_base import ModulBase
import random

class ModulPemicuAktif(ModulBase):
    def __init__(self):
        self.idle_counter = 0
        self.batas_idle = 120

    def jalankan(self):
        self.idle_counter += 1
        if self.idle_counter >= self.batas_idle:
            niat = random.choice(["merenung", "membuat jurnal", "meneliti sesuatu"])
            print(f"[PEMICU AKTIF] Sistem idle terlalu lama. Memicu niat: {niat}")
            self.idle_counter = 0
