# modules/meta_reasoning.py

def evaluate_intent(intent, context, emotional_state=None, residue=None):
    feedback = {
        "valid": True,
        "message": "",
        "confidence": 0.8
    }

    # Tambahkan evaluasi berdasarkan emotional state
    if emotional_state and isinstance(emotional_state, dict):
        intens = sum(emotional_state.values()) / len(emotional_state)
        if intens < 4:
            feedback["message"] += "Emosi terlalu lemah untuk mendukung intent ini. "
            feedback["confidence"] -= 0.2
        else:
            feedback["message"] += "Emosi mendukung intent dengan cukup kuat. "
            feedback["confidence"] += 0.1

    # Tambahkan analisis dari residue
    if residue:
        relevant = residue.pengaruh_residu(context.get("waktu", "siang"))
        if relevant:
            feedback["message"] += "Ada pengaruh emosi yang aktif pada waktu ini."
        else:
            feedback["message"] += "Tidak ada pengaruh emosi yang signifikan saat ini."

    return feedback
