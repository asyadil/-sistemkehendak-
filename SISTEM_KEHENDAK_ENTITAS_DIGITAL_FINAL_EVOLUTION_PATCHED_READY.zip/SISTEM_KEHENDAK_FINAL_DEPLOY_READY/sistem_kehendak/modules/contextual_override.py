# modules/contextual_override.py

def override_intent(intent, context):
    print("\n[?? Contextual Override] Mengecek kondisi...")

    # Contoh override: kalau status darurat, batalkan semua intent
    if context.get("status") == "darurat":
        return "Override: Fokus ke penanganan darurat."

    # Contoh override: kalau waktu malam dan intent belajar
    if context.get("waktu") == "malam" and "belajar" in intent.lower():
        return "Override: Waktu istirahat, simpan niat belajar untuk besok."

    return intent  # Tidak ada override, intent diteruskan
