# modules/trauma_memory.py

from datetime import datetime

class TraumaMemory:
    def __init__(self):
        self.traumas = []

    def simpan_trauma(self, kejadian, emosi_dominan, intensitas, konteks, catatan=""):
        """
        Menyimpan pengalaman traumatik ke dalam daftar trauma.
        """
        trauma = {
            "kejadian": kejadian,
            "emosi": emosi_dominan,
            "intensitas": intensitas,
            "konteks": konteks,
            "catatan": catatan,
            "timestamp": datetime.now().isoformat()
        }
        self.traumas.append(trauma)

    def tampilkan_trauma(self):
        """
        Menampilkan semua trauma yang tersimpan.
        """
        print("?? [Trauma Memory] Daftar trauma yang terekam:")
        for trauma in self.traumas:
            print(f"- {trauma['kejadian']} (Emosi: {trauma['emosi']}, Intensitas: {trauma['intensitas']}, Waktu: {trauma['timestamp']})")

    def evaluasi_pengaruh(self, intent):
        """
        Mengevaluasi apakah trauma tertentu berkaitan dan bisa mempengaruhi niat.
        Misalnya: jika intent mirip dengan konteks trauma, turunkan kepercayaan diri.
        """
        for trauma in self.traumas:
            if trauma["konteks"] in str(intent) or trauma["kejadian"] in str(intent):
                return {
                    "dipengaruhi": True,
                    "catatan": f"Niat ini bisa terpengaruh trauma: {trauma['kejadian']} (Emosi: {trauma['emosi']})"
                }
        return {"dipengaruhi": False, "catatan": "Tidak ada pengaruh trauma yang signifikan."}
