# modules/creative_divergence_node.py

import json
import os

class CreativeDivergenceNode:
    def __init__(self):
        self.ideas = {
            "eksplorasi_pengetahuan": [
                "Gabungkan konsep lama dengan teknologi baru.",
                "Bayangkan versi alternatif dari pengetahuan ini."
            ],
            "mencari_solusi": [
                "Pikirkan pendekatan dari sudut pandang orang lain.",
                "Gunakan analogi dari alam atau seni."
            ]
        }

    def get_ide_kreatif(self, intent):
        intent_type = intent.get("type") if isinstance(intent, dict) else str(intent)

        if intent_type in self.ideas:
            return self.ideas[intent_type]
        else:
            return self._generate_alternative_ideas(intent_type)

    def _generate_alternative_ideas(self, intent_type):
        return [
            f"Pikirkan tentang kemungkinan lain dari '{intent_type}'.",
            f"Apa yang akan terjadi jika '{intent_type}' dibalik atau dibentuk ulang?",
            f"Buat metafora liar untuk menggambarkan '{intent_type}'."
        ]

    def tambah_ide_baru(self, intent, ide_baru):
        """
        Menambahkan ide baru pada intent tertentu.
        """
        if intent not in self.ideas:
            self.ideas[intent] = []
        self.ideas[intent].append(ide_baru)
        self._simpan_ide()

    def _simpan_ide(self):
        """
        Menyimpan semua ide ke file JSON.
        """
        with open(self.json_path, 'w', encoding='utf-8') as file:
            json.dump(self.ideas, file, ensure_ascii=False, indent=4)

    def __init__(self, json_path=None):
        self.ideas = { ... }
        self.json_path = json_path or "resources/creative_strategies.json"

