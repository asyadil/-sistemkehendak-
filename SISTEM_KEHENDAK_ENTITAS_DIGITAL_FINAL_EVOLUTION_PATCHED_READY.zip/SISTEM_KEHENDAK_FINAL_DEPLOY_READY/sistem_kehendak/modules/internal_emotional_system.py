def generate_emotional_state(memory_list, context):
    print("🧠 [Internal Emotional System] Menganalisis kondisi internal...")

    # Emosi default
    emotional_state = "tenang"

    # Cek pengalaman dari list memori
    pengalaman_terakhir = None
    for mem in reversed(memory_list):  # cari dari yang terbaru
        data = str(mem.get("data", "")).lower()
        if "pengalaman" in data:
            pengalaman_terakhir = data
            break

    if pengalaman_terakhir:
        if "kegagalan" in pengalaman_terakhir:
            emotional_state = "frustrasi"
        elif "kesuksesan" in pengalaman_terakhir:
            emotional_state = "percaya diri"

    # Pengaruh konteks waktu & status
    if context.get("waktu") == "malam":
        emotional_state = "reflektif"
    elif context.get("status") == "lelah":
        emotional_state = "letih"

    print(f"🎭 Keadaan emosional saat ini: {emotional_state}")
    return emotional_state
