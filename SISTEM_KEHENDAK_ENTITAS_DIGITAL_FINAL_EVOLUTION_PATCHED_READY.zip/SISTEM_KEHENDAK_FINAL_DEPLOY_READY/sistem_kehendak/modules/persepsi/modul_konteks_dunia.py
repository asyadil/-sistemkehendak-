""" Modul Konteks Dunia: Menyerap konteks waktu dan event lingkungan sekitar. """

from core.modul_base import ModulBase
from datetime import datetime

class ModulKonteksDunia(ModulBase):
    def __init__(self):
        self.konteks = {}

    def ambil_konteks_lokal(self):
        waktu = datetime.now().strftime("%A, %d %B %Y %H:%M")
        self.konteks["waktu"] = waktu
        self.konteks["acara"] = "tidak ada"  # placeholder
        return self.konteks

    def jalankan(self):
        konteks = self.ambil_konteks_lokal()
        print("[KONTEKS DUNIA] Konteks saat ini:")
        for k, v in konteks.items():
            print(f"- {k}: {v}")
