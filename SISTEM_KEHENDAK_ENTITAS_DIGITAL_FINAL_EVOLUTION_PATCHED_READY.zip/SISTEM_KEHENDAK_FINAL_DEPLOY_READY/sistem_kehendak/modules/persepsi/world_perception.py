""" Modul World Perception: Membaca informasi dunia dari file eksternal. """

from core.modul_base import ModulBase
import json
import os

class WorldPerception(ModulBase):
    def __init__(self):
        self.sumber = "resources/info_dunia.json"
        self.data_terakhir = []

    def baca_info_dunia(self):
        if os.path.exists(self.sumber):
            with open(self.sumber, "r", encoding="utf-8") as f:
                data = json.load(f)
                self.data_terakhir = data.get("informasi", [])
                return self.data_terakhir
        return []

    def jalankan(self):
        info = self.baca_info_dunia()
        if info:
            print("[PERSEPSI DUNIA] Informasi diterima:")
            for entri in info:
                print(f"- {entri}")
        else:
            print("[PERSEPSI DUNIA] Tidak ada informasi ditemukan.")
