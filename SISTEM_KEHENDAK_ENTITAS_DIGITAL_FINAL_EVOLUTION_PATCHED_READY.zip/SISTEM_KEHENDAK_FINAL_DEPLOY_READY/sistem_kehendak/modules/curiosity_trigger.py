# modules/curiosity_trigger.py

import random

class CuriosityTrigger:
    def __init__(self, memory, emotional_residue):
        self.memory = memory
        self.emotional_residue = emotional_residue

    def detect_novelty(self):
        """
        Deteksi apakah ada hal baru di memori yang bisa memicu rasa ingin tahu.
        Misalnya berdasarkan kejadian yang jarang terjadi atau belum dipahami sepenuhnya.
        """
        if not self.memory:
            return False, "Memori kosong"

        unusual_events = [m for m in self.memory if m.get("frekuensi", 0) < 2]
        if unusual_events:
            trigger_reason = f"Ada {len(unusual_events)} kejadian langka"
            return True, trigger_reason
        return False, "Tidak ada hal baru"

    def evaluate_emotional_influence(self):
        """
        Evaluasi apakah emosi tertentu (misal: semangat, penasaran) sedang tinggi
        dan bisa memperkuat rasa ingin tahu.
        """
        emotions = self.emotional_residue.get_emotion_list()
        for e in emotions:
            if e["emosi"] in ["penasaran", "semangat"] and e["intensitas"] >= 6:
                return True, f"Emosi {e['emosi']} tinggi"
        return False, "Tidak ada pengaruh emosi signifikan"

    def generate_curiosity_intent(self):
        """
        Jika kondisi terpenuhi, hasilkan intent berdasarkan pemicu rasa ingin tahu.
        """
        novel, reason_novelty = self.detect_novelty()
        emotional, reason_emotion = self.evaluate_emotional_influence()

        if novel or emotional:
            reason = f"{reason_novelty}; {reason_emotion}"
            return {
                "type": "explore",
                "target": "informasi baru",
                "reason": reason
            }
        return None
