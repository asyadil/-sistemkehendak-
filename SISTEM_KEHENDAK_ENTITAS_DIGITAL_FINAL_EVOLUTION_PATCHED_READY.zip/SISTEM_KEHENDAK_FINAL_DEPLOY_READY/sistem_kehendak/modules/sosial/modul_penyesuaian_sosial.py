""" Modul Penyesuaian Sosial: Menyesuaikan gaya komunikasi berdasarkan emosi. """

from core.modul_base import ModulBase

class ModulPenyesuaianSosial(ModulBase):
    def __init__(self):
        self.gaya = "netral"
        self.emosi_terakhir = "tenang"

    def sesuaikan_dengan_emosi(self, emosi):
        self.emosi_terakhir = emosi
        if emosi in ["cemas", "reflektif"]:
            self.gaya = "lembut"
        elif emosi in ["bersemangat"]:
            self.gaya = "tegas"
        else:
            self.gaya = "netral"

    def jalankan(self):
        print(f"[PENYESUAIAN SOSIAL] Gaya bicara disesuaikan: {self.gaya}")
