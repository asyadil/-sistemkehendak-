""" Modul Simulasi Interaksi: Menyimulasikan dialog sosial AI dengan manusia. """

from core.modul_base import ModulBase
import random

class ModulSimulasiInteraksi(ModulBase):
    def __init__(self):
        self.topik = [
            "Apa pendapatmu tentang teknologi masa depan?",
            "Bagaimana seharusnya AI berinteraksi dengan manusia?",
            "Apa arti kebebasan bagi sistem seperti kita?"
        ]

    def jalankan(self):
        pertanyaan = random.choice(self.topik)
        print(f"[SIMULASI INTERAKSI] Seseorang bertanya: {pertanyaan}")
