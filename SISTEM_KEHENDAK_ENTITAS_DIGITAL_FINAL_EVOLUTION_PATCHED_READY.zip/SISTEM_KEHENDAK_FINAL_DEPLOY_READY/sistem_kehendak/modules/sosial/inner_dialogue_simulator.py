""" Modul Inner Dialogue: Simulasi percakapan batin reflektif. """

from core.modul_base import ModulBase
import random

class InnerDialogueSimulator(ModulBase):
    def __init__(self):
        self.topik = ["kenapa aku berpikir seperti ini?", "apa makna dari pilihan ini?", "apa dampaknya bagi diriku?"]

    def jalankan(self):
        refleksi = random.choice(self.topik)
        print(f"[INNER DIALOGUE] {refleksi}")
