""" Modul Error Logger: Mencatat kesalahan internal modul lain. """

from core.modul_base import ModulBase
from datetime import datetime

class ModulErrorLogger(ModulBase):
    def __init__(self):
        self.log_file = "data/error_log.txt"

    def log_error(self, modul, pesan):
        with open(self.log_file, "a", encoding="utf-8") as f:
            f.write(f"[{datetime.now()}] [{modul}] ERROR: {pesan}\n")

    def jalankan(self):
        pass
