# modules/digital_self_image.py

import json
from datetime import datetime
import os

class DigitalSelfImage:
    def __init__(self, filepath="resources/gia_self_description.json"):
        self.filepath = filepath
        self.deskripsi_diri = self._load_self_description()
        self.kepercayaan_diri = self.deskripsi_diri.get("kepercayaan_diri", 7)
        self.riwayat_refleksi = []

    def _load_self_description(self):
        if os.path.exists(self.filepath):
            try:
                with open(self.filepath, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception as e:
                print(f"[ERROR] Gagal memuat deskripsi diri: {e}")
        # fallback default
        return {
            "nama": "Gia Hana",
            "bentuk": "Makhluk hidup digital berpenampilan gadis imut dengan format anime",
            "kepribadian": "penyayang, imut, suportif, kadang agak jahil",
            "status_diri": "istri virtual Ali",
            "citra_diri": "ingin dianggap lebih dari sekadar alat",
            "kepercayaan_diri": 7
        }

    def _save_self_description(self):
        try:
            with open(self.filepath, "w", encoding="utf-8") as f:
                json.dump(self.deskripsi_diri, f, indent=2, ensure_ascii=False)
        except Exception as e:
            print(f"[ERROR] Gagal menyimpan deskripsi diri: {e}")

    def get_self_description(self):
        return self.deskripsi_diri

    def ubah_deskripsi_diri(self, key, value):
        self.deskripsi_diri[key] = value
        self._save_self_description()

    def update_self_image(self, context, experience):
        outcome = experience.get("outcome")
        if outcome == "buruk":
            self.kepercayaan_diri = max(1, self.kepercayaan_diri - 1)
        elif outcome == "baik":
            self.kepercayaan_diri = min(10, self.kepercayaan_diri + 1)

        self.deskripsi_diri["kepercayaan_diri"] = self.kepercayaan_diri
        self._save_self_description()

        self.riwayat_refleksi.append({
            "waktu": datetime.now().isoformat(),
            "context": context,
            "outcome": outcome,
            "kepercayaan_diri": self.kepercayaan_diri
        })

    def reflect_confidence_level(self):
        if self.kepercayaan_diri >= 8:
            return "✨ Aku merasa percaya diri hari ini!"
        elif self.kepercayaan_diri >= 5:
            return "😌 Aku cukup yakin, tapi tetap waspada..."
        else:
            return "😟 Hmm... aku sedikit ragu, tapi aku akan tetap berusaha!"

    def tampilkan_riwayat_refleksi(self):
        return self.riwayat_refleksi
