""" Modul ChatInterface: Menghubungkan niat & emosi ke output verbal (LLM). """

import requests
from core.modul_base import ModulBase

class ModulChatInterface(ModulBase):
    def __init__(self, endpoint="http://localhost:11434/api/generate", model="llama3"):
        self.endpoint = endpoint
        self.model = model

    def generate_response(self, prompt, emotion=None):
        payload = {
            "model": self.model,
            "prompt": self._format_prompt(prompt, emotion),
            "stream": False
        }
        try:
            response = requests.post(self.endpoint, json=payload)
            data = response.json()
            return data.get("response", "[No response]")
        except Exception as e:
            return f"[Error accessing LLM: {e}]"

    def _format_prompt(self, prompt, emotion):
        if emotion:
            return f"Emosi: {emotion}\nJawablah dengan gaya yang mencerminkan perasaan ini.\n\n{prompt}"
        return prompt

    def jalankan(self):
        pass
