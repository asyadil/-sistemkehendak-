
from core.modul_base import ModulBase
from datetime import datetime

class ModulDiagnostik(ModulBase):
    def __init__(self, system=None):
        self.system = system

    def jalankan(self):
        print("\n🧠 MODUL AKTIF:")
        if self.system and hasattr(self.system, 'modul_list'):
            for modul in self.system.modul_list:
                print(f"- {modul.__class__.__name__}")

        if self.system and hasattr(self.system, 'emosi') and self.system.emosi:
            print(f"\n💬 Emosi terakhir: {self.system.emosi.get('terbaru', 'tidak ada')}")

        if self.system and hasattr(self.system, 'tracker'):
            print(f"\n🧭 Niat jangka panjang:")
            for niat in self.system.tracker.riwayat[-3:]:
                print(f"- {niat}")

        try:
            with open("data/chatgpt_prompt_out.txt", "r", encoding="utf-8") as f:
                print("\n📤 Prompt terakhir untuk ChatGPT:")
                print(f.read())
        except:
            print("\n📤 Prompt terakhir belum tersedia.")
