""" Modul HeartbeatLogger: Mencatat denyut hidup sistem. """

from core.modul_base import ModulBase
from datetime import datetime

class HeartbeatLogger(ModulBase):
    def __init__(self):
        self.interval = 60
        self.counter = 0

    def jalankan(self):
        self.counter += 1
        if self.counter >= self.interval:
            self.counter = 0
            with open("data/heartbeat.log", "a", encoding="utf-8") as f:
                f.write(f"[{datetime.now()}] SYSTEM ACTIVE\n")
