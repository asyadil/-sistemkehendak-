# modules/digital_body_language.py

import random
import json
import os

class DigitalBodyLanguage:
    def __init__(self, resource_path="resources/body_language_library.json"):
        self.library = self._load_library(resource_path)

    def _load_library(self, path):
        if os.path.exists(path):
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
        else:
            return {}

    def interpret(self, emotional_state, context=None):
        """
        Kembalikan representasi bahasa tubuh berdasarkan emosi utama.
        """
        result = []
        if not emotional_state:
            return ["?? Gia diam santai tanpa ekspresi khusus."]

        if not isinstance(emotional_state, dict):
            emotional_state = {emotional_state: 1}

        for emosi, level in emotional_state.items():
            if emosi in self.library:
                result.append(random.choice(self.library[emosi]))
            else:
                result.append(f"?? Gia berekspresi dengan gerakan tubuh yang mencerminkan {emosi}.")

        return result
