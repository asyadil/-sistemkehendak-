# modules/decision_maker.py

def decide_and_explore(intent, memory_manager, emotional_state, emotional_residue):
    print("\n?? [Decision Maker] Mengambil keputusan berdasarkan intent dan kondisi...")

    decisions = []

    # Pertimbangan emosional utama
    if emotional_state == "frustrasi":
        print("?? Emosi dominan: frustrasi. Sistem menghindari keputusan berisiko.")
        decisions.append("evaluasi ulang keputusan")
    elif emotional_state == "percaya diri":
        print("?? Emosi dominan: percaya diri. Sistem siap mengambil langkah aktif.")
        decisions.append("eksplorasi agresif")
    elif emotional_state == "reflektif":
        print("?? Emosi dominan: reflektif. Sistem mendorong eksplorasi pemikiran.")
        decisions.append("refleksi internal")

    # Pertimbangan jejak emosi (emotional residue)
    dominant = emotional_residue.get_dominant_emotion()
    if dominant == "cemas":
        print("?? Residual: kecemasan terdeteksi. Sistem akan lebih hati-hati.")
        decisions.append("eksplorasi hati-hati")
    elif dominant == "semangat":
        print("?? Residual: semangat tinggi! Sistem terdorong untuk bertindak.")
        decisions.append("eksplorasi penuh semangat")

    # Gabungkan dengan intent
    final_decision = {
        "action": "eksplorasi",
        "target": intent.get("target", "tidak diketahui"),
        "strategi": decisions,
        "confidence": intent.get("confidence", "normal"),
        "note": intent.get("note", None)
    }

    print(f"\n? Keputusan akhir: {final_decision}")
    return final_decision
