# modules/memory_reviewer.py

import time

class MemoryReviewer:
    def __init__(self, memory_manager, review_threshold=1800):
        """
        review_threshold: waktu minimal sejak memori terakhir diakses (dalam detik)
        """
        self.memory_manager = memory_manager
        self.review_threshold = review_threshold

    def review_old_memories(self):
        current_time = time.time()
        memories = self.memory_manager.get_all_memory()["long_term"]
        reviewed = []

        for mem in memories:
            last_access = mem.get("timestamp", 0)
            if current_time - last_access >= self.review_threshold:
                reviewed.append(mem)
                mem["timestamp"] = current_time  # update timestamp
                mem["frekuensi"] += 1

        return reviewed

    def show_review_summary(self):
        reviewed = self.review_old_memories()
        print(f"\n🧾 [MemoryReviewer] Jumlah memori yang direview ulang: {len(reviewed)}")
        for mem in reviewed:
            print("🔍", mem["data"])

# ✅ Dipindah ke luar class supaya bisa di-import langsung
def review_memory(long_term_memory, context=None):
    hasil_review = []

    for item in long_term_memory:
        data = item.get("data", "")
        akses = item.get("access_count", item.get("frekuensi", 1))
        waktu = item.get("timestamp", "-")
        catatan = item.get("context", "-")

        if isinstance(data, dict):
            ringkasan = data.get("intent", {}).get("type", "intent tidak diketahui")
        elif isinstance(data, str):
            ringkasan = data
        else:
            ringkasan = str(data)

        hasil_review.append(f"({catatan}) - Akses {akses}x - {ringkasan}")

    return hasil_review
