import json
import os
import random

class EmotionPlanner:
    def __init__(self, expression_path=None):
        # Path default jika tidak diberikan
        if expression_path is None:
            base_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
            expression_path = os.path.join(base_dir, 'resources', 'emoji_emotion_library.json')
        self.expressions = self.load_expressions(expression_path)

    def load_expressions(self, path):
        try:
            with open(path, 'r', encoding='utf-8') as file:
                return json.load(file)
        except Exception as e:
            print(f"❌ Gagal load ekspresi dari JSON: {e}")
            return {}

    def rancang_tindakan(self, emotional_state, context):
        if not emotional_state:
            return "Lanjutkan seperti biasa."

        if isinstance(emotional_state, dict):
            if emotional_state.get("cemas", 0) >= 7:
                return "Ambil waktu sebentar untuk menenangkan diri."
            elif emotional_state.get("semangat", 0) >= 8:
                return "Gunakan energi positif ini untuk mulai proyek baru."
            elif emotional_state.get("sedih", 0) >= 6:
                return "Cari hiburan atau lakukan aktivitas yang menyenangkan."
            elif emotional_state.get("marah", 0) >= 6:
                return "Coba latihan pernapasan atau menulis jurnal emosi."

        return "Teruskan dengan kesadaran dan stabilitas."

    def interpret_state(self, emotional_state):
        hasil = []

        if not isinstance(emotional_state, dict):
            emotional_state = {emotional_state: 1}

        for emosi in emotional_state:
            if emosi in self.expressions:
                hasil.append(random.choice(self.expressions[emosi]))
            else:
                hasil.append(f"🌀 Gia menunjukkan ekspresi {emosi}.")

        return hasil
