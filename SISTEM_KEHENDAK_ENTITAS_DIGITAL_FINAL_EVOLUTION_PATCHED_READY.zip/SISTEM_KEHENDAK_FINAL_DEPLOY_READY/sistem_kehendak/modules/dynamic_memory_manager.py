import time
import difflib

class DynamicMemoryManager:
    def __init__(self):
        self.short_term_memory = []
        self.long_term_memory = []

    def add_memory(self, memory_data, context=None):
        item = {
            "data": memory_data,
            "context": context,
            "timestamp": time.time(),
            "access_count": 1
        }
        self.short_term_memory.append(item)

    def consolidate_memory(self):
        """
        Menggabungkan memori yang mirip di STM ke dalam LTM dengan versi ringkas.
        """
        threshold_similarity = 0.75
        clustered = []
        used_indexes = set()

        for i, mem1 in enumerate(self.short_term_memory):
            if i in used_indexes:
                continue
            cluster = [mem1]
            for j, mem2 in enumerate(self.short_term_memory):
                if j <= i or j in used_indexes:
                    continue
                similarity = difflib.SequenceMatcher(None, str(mem1["data"]), str(mem2["data"])).ratio()
                if similarity >= threshold_similarity:
                    cluster.append(mem2)
                    used_indexes.add(j)
            used_indexes.add(i)
            clustered.append(cluster)

        for cluster in clustered:
            if len(cluster) == 1:
                self.long_term_memory.append(cluster[0])
            else:
                merged_data = " | ".join([str(m["data"]) for m in cluster])
                merged_contexts = [m["context"] for m in cluster if m["context"]]
                merged_item = {
                    "data": f"Gabungan: {merged_data}",
                    "context": merged_contexts,
                    "timestamp": time.time(),
                    "access_count": max(m["access_count"] for m in cluster)
                }
                self.long_term_memory.append(merged_item)
        
        self.short_term_memory = []  # Kosongkan STM setelah konsolidasi
        print(f"🧠 [MemoryManager] Konsolidasi selesai. Total kluster: {len(clustered)}")


    def recall(self, query=None):
        result = []
        for mem in self.short_term_memory + self.long_term_memory:
            if query is None or query in str(mem["data"]):
                result.append(mem)
        return result

    def update_memory_access(self, memory_data):
        for mem in self.short_term_memory:
            if mem["data"] == memory_data:
                mem["access_count"] += 1
                break

    def clear_short_term(self):
        self.short_term_memory = []

    def get_all_memory(self):
        return {
            "short_term": self.short_term_memory,
            "long_term": self.long_term_memory
        }

    def add_experience(self, experience_data):
        """
        Menambahkan pengalaman penting langsung ke long-term memory.
        """
        item = {
            "data": experience_data,
            "context": "pengalaman",
            "timestamp": time.time(),
            "frekuensi": 1
        }
        self.long_term_memory.append(item)
        print("💾 [DynamicMemoryManager] Pengalaman baru ditambahkan ke LTM:", experience_data)
