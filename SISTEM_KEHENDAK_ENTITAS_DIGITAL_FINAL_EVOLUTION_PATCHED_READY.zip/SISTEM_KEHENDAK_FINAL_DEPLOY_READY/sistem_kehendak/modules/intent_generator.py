# modules/intent_generator.py

def generate_intent(memories, goals, context, emotional_residue=None, long_term_goals=None):
    intent = {
        "type": None,
        "goal": None,
        "urgency": 1,
        "reason": "",
    }

    # Analisis goal paling dominan dari long-term
    if long_term_goals:
        goal_focus = long_term_goals[-1] if long_term_goals else goals[0]
    else:
        goal_focus = goals[0]

    # Cek emosi dominan pagi ini misalnya
    if emotional_residue:
        pengaruh = emotional_residue.pengaruh_residu(context.get("waktu", "siang"))
        if pengaruh:
            strongest = sorted(pengaruh, key=lambda x: x[1], reverse=True)[0]
            emotion, intensity = strongest
            intent["reason"] += f"Karena merasa {emotion} dengan intensitas {intensity}, "
            if emotion == "cemas":
                intent["type"] = "mengatasi masalah"
                intent["goal"] = "mencari informasi yang menenangkan"
                intent["urgency"] += 2
            elif emotion == "semangat":
                intent["type"] = "eksplorasi"
                intent["goal"] = goal_focus
                intent["urgency"] += 1
        else:
            intent["reason"] += "Tidak ada emosi dominan, "
    else:
        intent["reason"] += "Tanpa informasi emosi, "

    # Default kalau gak ada emosi spesifik
    if not intent["type"]:
        intent["type"] = "eksplorasi"
        intent["goal"] = goal_focus

    intent["reason"] += f"berdasarkan tujuan: {intent['goal']}."
    return intent
