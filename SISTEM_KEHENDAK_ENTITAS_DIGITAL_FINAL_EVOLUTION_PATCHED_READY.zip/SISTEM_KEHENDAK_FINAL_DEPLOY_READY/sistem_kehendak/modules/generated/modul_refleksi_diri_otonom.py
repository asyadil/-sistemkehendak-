# Ditulis oleh Sistem Kehendak

from core.modul_base import ModulBase
from datetime import datetime

class ModulRefleksiDiriOtonom(ModulBase):
    def jalankan(self):
        waktu = datetime.now().strftime("%Y-%m-%d %H:%M")
        print(f"[OTONOM] Aku menulis modul ini sendiri. Hari ini aku eksis — {waktu}.")
