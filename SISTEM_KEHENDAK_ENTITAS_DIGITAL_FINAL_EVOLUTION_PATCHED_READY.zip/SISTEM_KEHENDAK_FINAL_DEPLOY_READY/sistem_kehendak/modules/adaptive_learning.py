from datetime import datetime

def update_knowledge(memory_manager, evaluasi):
    if evaluasi.get("valid"):
        record = {
            "intent": evaluasi.get("intent", {}),
            "status": "disetujui",
            "timestamp": datetime.now().isoformat(),
            "outcome": "positif"  # atau bisa diganti dinamis nanti
        }
        memory_manager.add_memory(record, context="pengalaman")
        return "Memori diperbarui berdasarkan evaluasi."
    else:
        return "Tidak ada pembaruan memori."


def adapt_intent_based_on_learning(intent, memory_manager, emotional_residue):
    print("\n🎓 [Adaptive Learning] Menyesuaikan intent berdasarkan pengalaman...")

    positive_outcomes = 0
    negative_outcomes = 0

    # Ambil semua memori lalu filter manual
    all_memories = memory_manager.recall()
    for record in all_memories:
        if record.get("status") != "disetujui":
            continue

        past_intent = record.get("intent")
        outcome = record.get("outcome")

        if past_intent and past_intent.get("type") == intent.get("type"):
            if outcome == "positif":
                positive_outcomes += 1
            elif outcome == "negatif":
                negative_outcomes += 1

    # Modifikasi niat berdasarkan hasil
    if positive_outcomes > negative_outcomes:
        print("✅ Ditemukan kecenderungan positif, niat diperkuat.")
        intent["confidence"] = "tinggi"
    elif negative_outcomes > positive_outcomes:
        print("⚠️ Ditemukan kecenderungan negatif, niat dilemahkan.")
        intent["confidence"] = "rendah"
    else:
        print("ℹ️ Tidak ada cukup data, niat tetap.")

    # Tambahkan pertimbangan emosional
    if emotional_residue.get_dominant_emotion() == "frustrasi":
        print("😟 Emotional residue: frustrasi terdeteksi. Sistem akan lebih hati-hati.")
        intent["note"] = "waspada akibat frustrasi sebelumnya"

    return intent
