# modules/curiosity_gateway.py

import random
from modules.world_perception import WorldPerception

class CuriosityGateway:
    def __init__(self):
        self.perception = WorldPerception()
        self.frekuensi_akses = "saat_dibutuhkan"  # bisa: realtime, berkala, saat_dibutuhkan
        self.fokus_awal = ["tren", "psikologi manusia", "kreativitas"]

    def eksplorasi(self, topik, preferensi=None):
        """
        Menyerap info dari dunia luar berdasarkan topik rasa penasaran.
        """
        if not topik:
            return "?Topik tidak tersedia."

        sumber_dipilih = preferensi or random.choice(self.fokus_awal)
        hasil = self.perception.cari_info(topik, sumber=sumber_dipilih)
        return {
            "topik": topik,
            "sumber": sumber_dipilih,
            "hasil": hasil
        }

    def evaluasi_eksplorasi(self, hasil):
        """
        Mengevaluasi apakah hasil eksplorasi memuaskan (sementara dummy).
        """
        if not hasil or "hasil" not in hasil:
            return False
        panjang = len(str(hasil.get("hasil")))
        return panjang > 50  # Sementara: panjang konten

