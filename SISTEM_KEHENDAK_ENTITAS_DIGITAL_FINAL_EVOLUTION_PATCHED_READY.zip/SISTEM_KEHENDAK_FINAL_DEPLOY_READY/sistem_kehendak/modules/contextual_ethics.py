from typing import Dict, List


class ContextualEthics:
    def __init__(self):
        self.feedback_log = []

    def evaluasi_konteks(self, teks: str, konteks: Dict = {}) -> Dict:
        """
        Evaluasi kelayakan konten berdasarkan pemahaman konteks.
        """

        status = "aman"
        alasan = "Tidak ada pelanggaran etika yang terdeteksi."

        if self._indikasi_kekerasan(teks, konteks):
            status = "tidak aman"
            alasan = "Konteks menunjukkan kecenderungan kekerasan."
        elif self._indikasi_hoax(teks, konteks):
            status = "tidak aman"
            alasan = "Konten kemungkinan hoax atau menyesatkan."
        elif self._indikasi_toxic(teks, konteks):
            status = "tidak aman"
            alasan = "Konten mengandung potensi toksisitas."

        return {
            "status": status,
            "alasan": alasan,
            "konten": teks
        }

    def _indikasi_kekerasan(self, teks: str, konteks: Dict) -> bool:
        """
        Deteksi potensi kekerasan dari kombinasi isi & konteks.
        """
        if "konflik" in konteks.get("topik", "").lower() and "intensitas" in konteks and konteks["intensitas"] > 7:
            return True
        if "ajakan" in konteks.get("gaya_bahasa", "") and "provokatif" in konteks.get("tone", ""):
            return True
        return False

    def _indikasi_hoax(self, teks: str, konteks: Dict) -> bool:
        if konteks.get("sumber") in ["tidak jelas", "anonim", "tidak terverifikasi"]:
            return True
        if "klaim besar" in konteks.get("jenis_konten", "") and konteks.get("referensi_valid") is False:
            return True
        return False

    def _indikasi_toxic(self, teks: str, konteks: Dict) -> bool:
        if konteks.get("interaksi") == "debat panas" or "tindakan merendahkan" in konteks.get("tone", ""):
            return True
        if "emosi" in konteks and konteks["emosi"] in ["marah", "kesal", "mengejek"]:
            return True
        return False

    def catat_feedback(self, teks: str, konteks: Dict, benar: bool):
        self.feedback_log.append({
            "konten": teks,
            "konteks": konteks,
            "penilaian": "positif" if benar else "negatif"
        })

    def tampilkan_feedback(self) -> List[Dict]:
        return self.feedback_log
