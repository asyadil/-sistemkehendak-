# modules/world_perception.py

from datetime import datetime
import random

class WorldPerception:
    def __init__(self):
        self.sources = ["reddit", "x", "youtube", "blog", "news"]
        self.fokus_utama = ["AI", "manusia", "psikologi", "musik"]
        self.mode = "on_demand"

    def ambil_info(self, topik=None):
        topik = topik or random.choice(self.fokus_utama)
        sumber = random.choice(self.sources)

        # Dummy data simulasi scraping/info
        info = {
            "judul": f"{topik.title()} Terbaru di {sumber}",
            "sumber": sumber,
            "konten": f"Artikel menarik tentang {topik} dari {sumber}...",
            "waktu": datetime.now().isoformat(),
            "relevansi": random.randint(6, 10),
            "emosi": random.choice(["penasaran", "senang", "cemas", "tertarik"])
        }

        return info

    def ringkas_info(self, info):
        return f"[{info['sumber'].upper()}] {info['judul']} ({info['relevansi']}/10): {info['konten']}"

    def dapatkan_semua_ringkasan(self, jumlah=3):
        return [self.ringkas_info(self.ambil_info()) for _ in range(jumlah)]
