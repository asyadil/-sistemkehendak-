from datetime import datetime

class FeedbackReflection:
    def __init__(self):
        self.daftar_feedback = []

    def catat_feedback(self, sumber, isi, emosi=None, konteks=None):
        """
        Menyimpan feedback dari luar, bisa dari pengguna atau sistem lain.
        """
        feedback = {
            "waktu": datetime.now().isoformat(),
            "sumber": sumber,
            "isi": isi,
            "emosi": emosi,
            "konteks": konteks
        }
        self.daftar_feedback.append(feedback)

    def refleksi_feedback(self):
        """
        Menghasilkan refleksi berdasarkan feedback yang masuk.
        """
        refleksi = []
        for fb in self.daftar_feedback[-5:]:  # fokus ke 5 terakhir
            pesan = f"Dari {fb['sumber']}: '{fb['isi']}'"
            if fb.get("emosi"):
                pesan += f" (nada emosi: {fb['emosi']})"
            refleksi.append(pesan)
        return refleksi

    def get_all_feedback(self):
        return self.daftar_feedback
