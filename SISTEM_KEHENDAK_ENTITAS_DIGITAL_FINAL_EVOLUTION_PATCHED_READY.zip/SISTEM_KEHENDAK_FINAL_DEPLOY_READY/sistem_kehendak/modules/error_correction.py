# modules/error_correction.py

class ErrorCorrection:
    def __init__(self):
        self.log_kesalahan = []

    def deteksi_kesalahan(self, hasil_evaluasi, intent, context):
        """
        Mendeteksi potensi kesalahan berdasarkan hasil evaluasi meta-reasoning atau outcome.
        """
        if not hasil_evaluasi or not isinstance(hasil_evaluasi, dict):
            return None

        if hasil_evaluasi.get("status") == "gagal":
            kesalahan = {
                "intent": intent,
                "context": context,
                "masalah": hasil_evaluasi.get("alasan", "Tidak diketahui"),
                "status": "butuh perbaikan"
            }
            self.log_kesalahan.append(kesalahan)
            return kesalahan
        return None

    def koreksi(self, intent, kesalahan):
        """
        Mengembalikan intent yang dikoreksi berdasarkan info kesalahan.
        """
        if not kesalahan:
            return intent

        # Contoh: ubah intent jika masalah spesifik terdeteksi
        if "tidak relevan" in kesalahan.get("masalah", ""):
            return {
                "type": "refleksi_diri",
                "goal": "memahami kesalahan sebelumnya",
                "reason": "karena sebelumnya tidak relevan dengan konteks"
            }
        elif "bertentangan" in kesalahan.get("masalah", ""):
            return {
                "type": "penyesuaian_prioritas",
                "goal": "sinkronisasi tujuan dan kondisi",
                "reason": "untuk mencegah konflik batin"
            }

        return intent

    def tampilkan_log(self):
        return self.log_kesalahan
