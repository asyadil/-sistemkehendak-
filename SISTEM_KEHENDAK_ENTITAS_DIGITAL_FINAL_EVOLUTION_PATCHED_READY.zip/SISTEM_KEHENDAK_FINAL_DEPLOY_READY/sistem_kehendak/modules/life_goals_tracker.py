# modules/life_goals_tracker.py

class LifeGoalsTracker:
    def __init__(self):
        self.goals = []

    def tambah_goal(self, goal_data):
        if goal_data not in self.goals:
            self.goals.append(goal_data)

    def cek_kesesuaian(self, intent):
        relevant = any(goal.lower() in intent.get("reason", "").lower() for goal in self.goals)
        return relevant

    def tampilkan_goal(self):
        if not self.goals:
            print("?? Belum ada tujuan hidup yang disimpan.")
        else:
            print("?? Tujuan Hidup:")
            for idx, goal in enumerate(self.goals, 1):
                print(f"{idx}. {goal}")
