class EmotionalResidue:
    def __init__(self):
        self.residu = []

    def simpan_residu(self, emosi, intensitas, konteks):
        self.residu.append({
            "emosi": emosi,
            "intensitas": intensitas,
            "konteks": konteks
        })

    def tampilkan_residu(self):
        print("📜 Jejak Emosi Tersimpan:")
        for item in self.residu:
            print(f"- {item['emosi']} (Intensitas: {item['intensitas']}, Konteks: {item['konteks']})")

    def pengaruh_residu(self, konteks_saat_ini):
        hasil = []
        for item in self.residu:
            if item["konteks"] == konteks_saat_ini:
                hasil.append((item["emosi"], item["intensitas"]))
        return hasil

    def summary(self):
        return [
            {"emosi": emosi, "intensitas": intensitas, "konteks": konteks}
            for emosi, intensitas, konteks in self.residu
        ]

    def get_dominant_emotion(self):
        if not self.residu:
            return None

    def get_emotion_list(self):
        return self.residu


        emosi_dominan = max(self.residu, key=lambda x: x["intensitas"])
        return emosi_dominan["emosi"]
