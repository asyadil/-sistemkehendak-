# modules/jurnal_internal.py
from datetime import datetime

class JurnalInternal:
    def __init__(self):
        self.entri_jurnal = []

    def tulis_jurnal(self, entry, context=None):
        catatan = {
            "waktu": datetime.now().isoformat(),
            "isi": entry,
            "konteks": context or {}
        }
        self.entri_jurnal.append(catatan)

    def tampilkan_jurnal(self):
        if not self.entri_jurnal:
            print("?? Tidak ada entri jurnal.")
            return

        print("\n?? [JURNAL INTERNAL]:")
        for i, entri in enumerate(self.entri_jurnal, start=1):
            waktu = entri["waktu"]
            isi = entri["isi"]
            konteks = entri.get("konteks", {})
            print(f"{i}. [{waktu}] - {isi}")
            if konteks:
                print(f"   Konteks: {konteks}")

    def filter_jurnal_by_context(self, kunci):
        hasil = [e for e in self.entri_jurnal if kunci in str(e.get("konteks", {}))]
        return hasil

    def ringkas_jurnal(self):
        if not self.entri_jurnal:
            return "Jurnal masih kosong."

        ringkasan = "?? Ringkasan Jurnal:\n"
        for e in self.entri_jurnal:
            ringkasan += f"- {e['isi']} (pada {e['waktu']})\n"
        return ringkasan
