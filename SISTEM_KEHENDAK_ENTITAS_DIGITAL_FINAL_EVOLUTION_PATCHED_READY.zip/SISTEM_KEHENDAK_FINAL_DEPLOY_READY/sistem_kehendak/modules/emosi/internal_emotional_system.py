""" Internal Emotional System: Mengatur dan merespons emosi dari dunia luar. """

from core.modul_base import ModulBase
from datetime import datetime
import os
BASE = os.path.dirname(__file__)

class InternalEmotionalSystem(ModulBase):
    def __init__(self):
        self.emosi_aktif = "tenang"

    def update_dari_persepsi_dunia(self, info_dunia):
        pemetaan = {
            "konflik": "cemas",
            "cuaca": "waspada",
            "AI": "penasaran",
            "etika": "reflektif",
            "teknologi": "bersemangat",
        }
        hasil = []
        for entri in info_dunia:
            for k, e in pemetaan.items():
                if k.lower() in entri.lower():
                    self.emosi_aktif = e
                    hasil.append((entri, e))
        return hasil

    def jalankan(self):
        print(f"[EMOSI] Emosi aktif saat ini: {self.emosi_aktif}")
