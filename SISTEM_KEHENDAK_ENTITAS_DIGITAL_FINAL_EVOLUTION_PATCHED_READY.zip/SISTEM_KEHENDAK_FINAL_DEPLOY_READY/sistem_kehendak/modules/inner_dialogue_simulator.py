# modules/inner_dialogue_simulator.py

class InnerDialogueSimulator:
    def __init__(self):
        self.dialogue_history = []

    def generate_internal_thoughts(self, intent, context, emotional_state):
        thoughts = [
            f"Apa keputusan ini cocok dengan niat '{intent.get('type')}' terhadap '{intent.get('target')}'?",
            f"Dalam konteks '{context.get('status')}', apakah tindakan ini wajar?",
            f"Emosi saat ini adalah '{emotional_state}', apakah itu mempengaruhi pertimbangan?",
        ]
        self.dialogue_history.append({"type": "thoughts", "content": thoughts})
        return thoughts

    def reflect_on_thoughts(self, thoughts):
        responses = []
        for thought in thoughts:
            if "cocok" in thought or "mempengaruhi" in thought:
                responses.append(f"?? {thought} ? Perlu dipikirkan ulang.")
            else:
                responses.append(f"? {thought} ? Tidak ada masalah.")
        self.dialogue_history.append({"type": "reflection", "content": responses})
        return responses

    def tampilkan_dialog_batin(self):
        print("\n?? [Inner Dialogue] Riwayat dialog batin:")
        for entry in self.dialogue_history:
            print(f"\n?? {entry['type'].capitalize()}:")
            for line in entry["content"]:
                print(f"   {line}")

class InnerDialogueSimulator:
    def __init__(self):
        pass

    def generate_thoughts(self, intent, context, emotional_state):
        thoughts = [
            f"Apa ini keputusan terbaik? Intent: {intent}",
            f"Dengan kondisi saat ini ({context.get('status')}), apa ini yang paling masuk akal?",
            f"Emosi sekarang: {emotional_state}, apa ini memengaruhi penilaian?"
        ]
        return thoughts

    def evaluate_doubts(self, thoughts):
        doubt_responses = []
        for t in thoughts:
            if "keputusan terbaik" in t or "memengaruhi penilaian" in t:
                doubt_responses.append(f"🤔 {t} → Muncul keraguan.")
            else:
                doubt_responses.append(f"✅ {t} → Dipertahankan.")
        return doubt_responses

class InnerDialogueSimulator:
    def __init__(self):
        pass

    def generate_thoughts(self, intent, context, emotional_state):
        thoughts = [
            f"Apa intent ini terbaik? → {intent}",
            f"Dalam konteks {context.get('status')}, apakah ini niat yang rasional?",
            f"Emosi sekarang: {emotional_state}. Apakah mempengaruhi penilaian?"
        ]
        return thoughts

    def evaluate_doubt(self, thoughts):
        doubts = []
        for t in thoughts:
            if "terbaik" in t or "mempengaruhi" in t:
                doubts.append(f"🤔 {t} ➜ Muncul keraguan.")
            else:
                doubts.append(f"✅ {t} ➜ Dipertahankan.")
        return doubts
