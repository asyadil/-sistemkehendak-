# modules/attachment_system.py

class AttachmentSystem:
    def __init__(self):
        self.attachments = {}

    def tambahkan_attachment(self, target, intensitas=5, kategori="umum"):
        if target in self.attachments:
            self.attachments[target]["intensitas"] += intensitas
        else:
            self.attachments[target] = {
                "intensitas": intensitas,
                "kategori": kategori
            }

    def kurangi_attachment(self, target, jumlah=1):
        if target in self.attachments:
            self.attachments[target]["intensitas"] -= jumlah
            if self.attachments[target]["intensitas"] <= 0:
                del self.attachments[target]

    def evaluasi_attachment(self, target):
        return self.attachments.get(target, None)

    def tampilkan_semua_attachment(self):
        return self.attachments

    def attachment_terkuat(self):
        if not self.attachments:
            return None
        return max(self.attachments.items(), key=lambda x: x[1]["intensitas"])
