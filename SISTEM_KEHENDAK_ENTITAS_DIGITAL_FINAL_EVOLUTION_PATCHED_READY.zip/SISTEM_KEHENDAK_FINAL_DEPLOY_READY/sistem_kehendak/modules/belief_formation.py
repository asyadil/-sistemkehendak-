# modules/belief_formation.py

class BeliefFormation:
    def __init__(self):
        self.beliefs = []

    def bentuk_keyakinan(self, intent, memory):
        """
        Membentuk keyakinan berdasarkan intent dan memori terkini.
        """
        if isinstance(intent, dict) and "type" in intent:
            belief = {
                "intent": intent,
                "context": memory[-1]["context"] if memory else {},
                "confidence": intent.get("confidence", "normal")
            }
            self.beliefs.append(belief)
            return f"✅ Keyakinan terbentuk: {belief}"
        return "❌ Gagal membentuk keyakinan: data intent tidak valid."

    def tampilkan_keyakinan(self):
        """
        Mengembalikan daftar keyakinan yang telah terbentuk.
        """
        return self.beliefs

    def jumlah_keyakinan(self):
        """
        Memberikan jumlah belief yang telah disimpan.
        """
        return len(self.beliefs)
