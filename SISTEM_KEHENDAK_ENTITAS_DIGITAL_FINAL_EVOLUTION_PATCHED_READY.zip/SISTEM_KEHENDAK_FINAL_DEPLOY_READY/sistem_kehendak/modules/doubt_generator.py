# modules/doubt_generator.py

def simulate_inner_dialogue(intent, context, emotional_state):
    thoughts = [
        f"Apa ini keputusan terbaik? Intent sekarang: {intent}",
        f"Dengan kondisi saat ini ({context.get('status')}), apa ini yang paling masuk akal?",
        f"Emosi yang dirasakan sekarang adalah {emotional_state}, apakah ini memengaruhi penilaian?"
    ]
    return thoughts

def simulate_self_doubt(thoughts):
    doubt_responses = []
    for t in thoughts:
        if "keputusan terbaik" in t or "memengaruhi penilaian" in t:
            doubt_responses.append(f"?? {t} -> Muncul keraguan.")
        else:
            doubt_responses.append(f"? {t} -> Dipertahankan.")
    return doubt_responses
