# modules/goal_manager.py

class GoalManager:
    def __init__(self):
        self.goals = []

    def tambahkan_goal(self, goal, prioritas=1, konteks=None):
        self.goals.append({
            "deskripsi": goal,
            "prioritas": prioritas,
            "konteks": konteks,
            "status": "aktif"
        })

    def evaluasi_goals(self, context, emotional_residue):
        hasil = []
        for goal in self.goals:
            intensitas_emosi = sum(
                i for e, i in emotional_residue.pengaruh_residu(context.get("waktu")) 
                if e in goal.get("deskripsi", "")
            )
            relevansi = goal["prioritas"] + intensitas_emosi
            hasil.append((goal, relevansi))
        hasil.sort(key=lambda x: x[1], reverse=True)
        return hasil

    def tampilkan_goals(self):
        for goal in self.goals:
            print(f"- {goal['deskripsi']} (Prioritas: {goal['prioritas']})")
