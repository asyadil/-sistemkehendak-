# modules/long_term_intent_tracker.py

class LongTermIntentTracker:
    def __init__(self):
        self.long_term_intents = []

    def tambahkan_intent_jangka_panjang(self, intent):
        print("?? [LT Intent Tracker] Menambahkan intent jangka panjang...")
        self.long_term_intents.append({
            "intent": intent,
            "status": "aktif",
            "evaluasi_terakhir": None
        })

    def evaluasi_intents(self, context, emotional_state):
        print("?? [LT Intent Tracker] Mengevaluasi intent jangka panjang...")
        hasil_evaluasi = []
        for item in self.long_term_intents:
            if item["status"] != "aktif":
                continue

            intent = item["intent"]
            relevansi = self.cek_relevansi(intent, context, emotional_state)

            if relevansi < 0.4:
                print(f"?? Intent {intent['type']} dianggap tidak lagi relevan.")
                item["status"] = "nonaktif"
            else:
                print(f"? Intent {intent['type']} masih relevan.")
            item["evaluasi_terakhir"] = relevansi
            hasil_evaluasi.append((intent, relevansi))
        return hasil_evaluasi

    def cek_relevansi(self, intent, context, emotional_state):
        # Penilaian dummy: bisa dikembangkan nanti
        if emotional_state == "frustrasi":
            return 0.2  # misal lagi frustrasi, jadi tujuan jangka panjang tertunda
        elif context.get("status") == "aktif":
            return 0.9
        return 0.5

    def tampilkan_semua_intent(self):
        print("?? [LT Intent Tracker] Daftar intent jangka panjang:")
        for item in self.long_term_intents:
            status = item["status"]
            intent = item["intent"]
            print(f"- {intent['type']} ke {intent.get('target', '???')} [{status}]")
