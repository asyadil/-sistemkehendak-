# modules/goal_evaluator.py

class GoalEvaluator:
    def __init__(self):
        self.goal_log = []

    def evaluasi_goal(self, intent, outcome, goals):
        """
        Mengevaluasi apakah intent & outcome mendekatkan sistem ke goal jangka panjang.
        Return: skor relevansi (0.0 - 1.0) dan alasan.
        """
        if not goals or not intent:
            return 0.0, "Tujuan atau intent kosong."

        skor = 0
        alasan = []

        for goal in goals:
            if goal.lower() in intent.get("target", "").lower():
                skor += 0.5
                alasan.append(f"Target sesuai dengan goal: '{goal}'")

            if goal.lower() in outcome.lower():
                skor += 0.5
                alasan.append(f"Outcome sesuai dengan goal: '{goal}'")

        skor = min(skor, 1.0)
        hasil = {
            "skor": skor,
            "alasan": alasan
        }

        # log penilaian
        self.goal_log.append(hasil)
        return skor, alasan

    def tampilkan_log(self):
        return self.goal_log
