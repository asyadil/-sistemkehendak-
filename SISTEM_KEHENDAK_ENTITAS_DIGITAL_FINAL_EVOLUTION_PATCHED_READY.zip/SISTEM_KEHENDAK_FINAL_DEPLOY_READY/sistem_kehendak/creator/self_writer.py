# Self-Writing Modul Creator

import os
from datetime import datetime

def tulis_modul(nama, isi, folder="modules/generated"):
    os.makedirs(folder, exist_ok=True)
    path = os.path.join(folder, f"{nama}.py")
    dengan = f"# Ditulis oleh Sistem Kehendak pada {datetime.now()}\n"
    with open(path, "w", encoding="utf-8") as f:
        f.write(dengan + isi)
    print(f"[SELF WRITER] Modul ditulis: {path}")
    return path
