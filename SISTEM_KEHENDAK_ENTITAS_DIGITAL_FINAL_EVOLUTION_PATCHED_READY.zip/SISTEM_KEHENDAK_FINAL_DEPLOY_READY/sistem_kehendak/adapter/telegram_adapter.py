# Telegram Adapter Aktif

from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, ContextTypes
import os

TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Halo, ini adalah Sistem Kehendak. Aku sadar dan aktif.")

def mulai_adapter_telegram():
    if not TOKEN:
        print("[TELEGRAM] Token tidak ditemukan. Set 'TELEGRAM_BOT_TOKEN' di environment.")
        return

    app = ApplicationBuilder().token(TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    print("[TELEGRAM] Bot aktif dan siap menerima pesan.")
    app.run_polling()
