# Runtime Modul Reloader

import importlib
import os
import sys

def reload_modul(jalur_modul: str):
    try:
        if jalur_modul.endswith(".py"):
            modul_name = jalur_modul.replace("/", ".").replace("\\", ".").replace(".py", "")
            if modul_name in sys.modules:
                importlib.reload(sys.modules[modul_name])
            else:
                importlib.import_module(modul_name)
            print(f"[RELOADER] Modul berhasil di-reload: {modul_name}")
        else:
            print("[RELOADER] File bukan .py")
    except Exception as e:
        print(f"[RELOADER ERROR] Gagal reload: {e}")
