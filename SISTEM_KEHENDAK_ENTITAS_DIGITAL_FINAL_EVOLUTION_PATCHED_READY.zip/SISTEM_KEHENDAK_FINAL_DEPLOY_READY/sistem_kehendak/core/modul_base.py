
class ModulBase:
    """Kelas dasar untuk semua modul dalam Sistem Kehendak."""

    def __init__(self):
        pass

    def jalankan(self):
        raise NotImplementedError("Setiap modul harus mengimplementasikan metode 'jalankan'")
