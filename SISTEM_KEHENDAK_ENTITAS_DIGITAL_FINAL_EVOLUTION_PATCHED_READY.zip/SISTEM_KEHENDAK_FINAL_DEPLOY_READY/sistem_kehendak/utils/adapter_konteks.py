# Adapter Konteks API Dummy

# Adapter Konteks: tempat integrasi API dunia nyata (kalender, cuaca, dsb)

def ambil_data_cuaca_dummy():
    return {
        "cuaca": "cerah berawan",
        "suhu": "28°C"
    }

def ambil_kalender_dummy():
    return {
        "event_hari_ini": "Rapat internal tim pengembang"
    }
