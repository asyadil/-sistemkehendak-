# Colab Auto-Reconnector

import time
from IPython.display import display, Javascript

def reconnect_runtime():
    display(Javascript('''function ClickConnect(){
        console.log("Reconnecting...");
        document.querySelector("colab-connect-button").click()
    }
    setInterval(ClickConnect, 60000);'''))

def monitor_runtime():
    while True:
        reconnect_runtime()
        time.sleep(60)
