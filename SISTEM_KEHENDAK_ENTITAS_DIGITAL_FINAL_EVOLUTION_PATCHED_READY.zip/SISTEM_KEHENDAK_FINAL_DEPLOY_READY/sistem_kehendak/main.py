# main.py

from core.system_manager import start_system

if __name__ == "__main__":
    start_system()
