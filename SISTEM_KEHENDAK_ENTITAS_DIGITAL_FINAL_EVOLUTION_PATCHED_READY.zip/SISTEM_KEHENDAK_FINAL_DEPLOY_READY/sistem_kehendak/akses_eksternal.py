
from system_manager import SystemManager

def akses_sistem():
    system = SystemManager()
    system.load_modul()

    print("\n🧠 MODUL AKTIF:")
    for modul in system.modul_list:
        print(f"- {modul.__class__.__name__}")

    if hasattr(system, "emosi") and system.emosi:
        print(f"\n💬 Emosi terakhir: {system.emosi.get('terbaru', 'tidak ada')}")

    if hasattr(system, "tracker"):
        print(f"\n🧭 Niat jangka panjang:")
        for niat in system.tracker.riwayat[-3:]:
            print(f"- {niat}")

    try:
        with open("data/chatgpt_prompt_out.txt", "r", encoding="utf-8") as f:
            print("\n📤 Prompt terakhir untuk ChatGPT:")
            print(f.read())
    except:
        print("\n📤 Prompt terakhir belum tersedia.")
