
from learning_agents.web_hunting_agent import WebHuntingAgent
from learning_agents.data_parser import DataParser
from learning_agents.learning_memory import LearningMemory

import time

# Inisialisasi Agen Pembelajaran
hunter = WebHuntingAgent()
parser = DataParser()
memory = LearningMemory('learning_memory.jsonl')

# Simulasi loop refleksi utama
while True:
    print("\n[Refleksi] Tidak ada tujuan aktif, sistem akan mencari data untuk belajar.")
    try:
        # Cari topik acak
        topic = "Artificial Intelligence news"
        links = hunter.search_web(topic)

        for link in links:
            raw_content = hunter.fetch_content(link)
            clean_data = parser.clean_text(raw_content)
            summary = parser.extract_summary(clean_data)
            memory.save_entry(source_url=link, parsed_data=summary)
            print(f"[Belajar] Data disimpan dari: {link}")

    except Exception as e:
        print(f"[Refleksi] Error dalam proses belajar mandiri: {e}")

    print("[Status] Menunggu 10 menit sebelum pencarian ulang...")
    time.sleep(600)  # 10 menit delay antar pembelajaran
