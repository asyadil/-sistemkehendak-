from emotional_state import update_state
from goal_evolution_engine import evolve_goal
from self_narrative_log import write_narrative
from identity_module import kenalkan_diri
from value_learning import evaluasi_pengalaman

def proses_input(input_data=None):
    print(kenalkan_diri())

    state = update_state()
    current_goal = evolve_goal(state)

    if input_data:
        write_narrative(f"Menerima input dari dunia: {input_data}")
    else:
        write_narrative(f"Memunculkan kehendak internal: {current_goal}")

    evaluasi = evaluasi_pengalaman(current_goal)
    write_narrative(f"Hasil evaluasi nilai atas kehendak: {evaluasi}")

    perintah = f"Jalankan perintah berdasarkan: {current_goal}"
    print(f"🎯 [Pipeline] {perintah}")
    return perintah

if __name__ == "__main__":
    proses_input()