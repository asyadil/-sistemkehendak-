
from learning_agents.exploratory_social_agent import ExploratorySocialAgent

# Inisialisasi agen sosial proaktif
exploratory_agent = ExploratorySocialAgent()

def social_exploration_loop():
    """Loop hunting target sosial dan inisiasi obrolan proaktif."""
    simulated_internet_pool = ['UserA', 'UserB', 'UserC', 'AI_ChatX', 'ForumBotY', 'HumanZ']
    exploratory_agent.discover_new_targets(simulated_internet_pool)
    exploratory_agent.initiate_interaction()
    return exploratory_agent.reflect_on_social_expansion()



from learning_agents.feedback_trainer import FeedbackTrainer
from learning_agents.contextual_adaptation import ContextualAdaptation
from learning_agents.massive_data_collector import MassiveDataCollector
from learning_agents.language_pattern_refiner import LanguagePatternRefiner

feedback_trainer = FeedbackTrainer()
context_adapter = ContextualAdaptation()
data_collector = MassiveDataCollector()
pattern_refiner = LanguagePatternRefiner()

def evaluate_and_evolve(output_text, human_id):
    """Evaluasi output AI berdasarkan feedback sosial dan refinement pola."""
    adapted_style = context_adapter.get_human_style(human_id)
    print(f"[ReflectiveAgent] Adaptasi gaya {human_id}: {adapted_style}")

    all_feedback = feedback_trainer.load_feedback()
    pattern_refiner.learn_from_feedback(all_feedback)

    refined = pattern_refiner.suggest_output(output_text)
    print(f"[ReflectiveAgent] Refinement hasil refleksi: {refined}")
    return refined



def evaluasi_reflektif(tujuan, kehendak, perintah):
    penilaian = []

    if not tujuan or not kehendak or not perintah:
        penilaian.append("Beberapa elemen kosong, evaluasi tidak lengkap.")

    if tujuan and kehendak and tujuan not in kehendak:
        penilaian.append("Kehendak tampak tidak mencerminkan tujuan.")
    
    if kehendak and perintah and kehendak not in perintah:
        penilaian.append("Perintah tampaknya tidak berasal dari kehendak.")

    if not penilaian:
        penilaian.append("✅ Semua elemen selaras secara logis.")

    return penilaian
