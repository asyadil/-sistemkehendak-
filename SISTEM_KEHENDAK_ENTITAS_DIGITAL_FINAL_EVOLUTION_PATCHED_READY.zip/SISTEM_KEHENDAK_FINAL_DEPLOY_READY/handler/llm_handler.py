import time

class LLMHandler:
    def __init__(self):
        self.chat_log = []

    def kirim_prompt(self, prompt):
        """
        Simulasi komunikasi dengan UI ChatGPT berbasis metode world_perception.
        Prompt dicatat sebagai log, dan diasumsikan ChatGPT akan merespons via sistem eksternal.
        """
        self.chat_log.append({"role": "user", "content": prompt})
        print(f"[PROMPT TERKIRIM KE CHATGPT UI]:\n{prompt}\n")
        self.tunggu_intervensi_manual()

    def tunggu_intervensi_manual(self):
        """
        Tunggu sampai user mengisi respons ke log eksternal (misal file .response atau stdin).
        Untuk simulasi awal, hanya delay sebagai placeholder.
        """
        print("⏳ Menunggu respons dari ChatGPT UI (simulasi)...")
        time.sleep(3)  # simulasi delay
        print("✅ Respons diterima (dummy, bisa diganti akses file atau input)")

    def ambil_respons_terakhir(self):
        # Untuk sistem nyata, ambil dari file, clipboard, atau shared log
        return "Ini adalah respons dummy dari ChatGPT UI."

    def reset_chat(self):
        self.chat_log.clear()
