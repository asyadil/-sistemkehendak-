import json
import os

def load_config(path="config.json"):
    if not os.path.exists(path):
        raise FileNotFoundError(f"Config file '{path}' tidak ditemukan.")
    
    with open(path, "r") as f:
        config = json.load(f)
    
    return config
