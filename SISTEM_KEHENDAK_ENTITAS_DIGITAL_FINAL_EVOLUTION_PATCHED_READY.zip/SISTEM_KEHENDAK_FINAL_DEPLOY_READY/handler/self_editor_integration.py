
from handler.self_editor import rewrite_file, validate_code_syntax, backup_file
from memory.logger import log_aktivitas
import os, json
from datetime import datetime

REWRITE_LOG = "memory/rewrite_log.jsonl"

def generate_code_from_prompt(prompt):
    # Dummy untuk testing self-rewrite
    return """def proses_input(input_user):\n    return {\n        'tujuan': input_user,\n        'kehendak': 'Testing self-modified kehendak',\n        'perintah': 'Laksanakan hasil modifikasi otomatis.'\n    }"""

def trigger_self_edit(tujuan):
    prompt = "Saya ingin memodifikasi logika handler agar sesuai dengan tujuan: {}. Berikan kode Python baru.".format(tujuan)
    kode_baru = generate_code_from_prompt(prompt)

    if not validate_code_syntax(kode_baru):
        catat_rewrite("handler/pipeline_handler.py", tujuan, "GAGAL - syntax error", kode_baru)
        return "❌ Gagal: Kode tidak valid."

    backup_file("handler/pipeline_handler.py")
    rewrite_file("handler/pipeline_handler.py", kode_baru)
    catat_rewrite("handler/pipeline_handler.py", tujuan, "BERHASIL", kode_baru)
    return "✅ Rewrite berhasil berdasarkan tujuan."

def catat_rewrite(file_path, tujuan, status, code):
    entry = {
        "timestamp": datetime.now().isoformat(),
        "file": file_path,
        "tujuan": tujuan,
        "status": status,
        "preview_code": code[:100]
    }
    os.makedirs("memory", exist_ok=True)
    with open(REWRITE_LOG, "a") as f:
        f.write(json.dumps(entry) + "\n")
