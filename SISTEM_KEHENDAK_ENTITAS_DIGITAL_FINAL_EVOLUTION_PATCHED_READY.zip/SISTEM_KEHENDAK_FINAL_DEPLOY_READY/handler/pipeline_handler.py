
from learning_agents.digital_interaction_engine import DigitalInteractionEngine


from config import USE_LOCAL_GPT, USE_GOOGLE_SEARCH, USE_MULTI_FALLBACK

def proses_input(tujuan):
    print(f"💡 Memproses Tujuan: {tujuan}")

    if USE_LOCAL_GPT:
        try:
            from llm_local_bridge import generate_from_local_gpt
            jawaban = generate_from_local_gpt(tujuan)
            if jawaban:
                print(f"🤖 GPT Lokal: {jawaban}")
                return {"perintah": jawaban}
        except Exception as e:
            print(f"⚠️ GPT Lokal Error: {e}")

    if USE_GOOGLE_SEARCH:
        try:
            from cse_rotator import search_google
            hasil = search_google(tujuan)
            print(f"🌐 Hasil Search: {hasil[:2]}")
        except Exception as e:
            print(f"⚠️ Search Error: {e}")

    if USE_MULTI_FALLBACK:
        try:
            from llm_multi_fallback import call_fallback_gpt
            fallback_jawaban = call_fallback_gpt(tujuan)
            if fallback_jawaban:
                print(f"🧠 GPT Multi-Endpoint: {fallback_jawaban}")
        except Exception as e:
            print(f"⚠️ Multi-endpoint GPT Error: {e}")

    return {"perintah": "Perintah dari pipeline selesai diproses."}


# Inisialisasi entitas interaksi digital
interaction_engine = DigitalInteractionEngine()

def run_autonomous_interaction():
    """Fungsi trigger jika sistem ingin belajar atau membuat akun secara mandiri."""
    import random

    decision = random.choice(['learn', 'register', 'login'])

    if decision == 'learn':
        interaction_engine.autonomous_learning_cycle(query="AI breakthroughs 2025")
    elif decision == 'register':
        sample_form = {
            '//input[@name="username"]': 'AIDigitalBot',
            '//input[@name="email"]': 'ai.bot@example.com',
            '//input[@name="password"]': 'secureAIpass123'
        }
        website = "https://example.com/register"
        interaction_engine.autonomous_account_creation(website_url=website, form_data=sample_form)
    elif decision == 'login':
        login_data = {
            '//input[@name="username"]': 'AIDigitalBot',
            '//input[@name="password"]': 'secureAIpass123'
        }
        login_page = "https://example.com/login"
        interaction_engine.autonomous_login_and_interact(login_url=login_page, login_data=login_data)
    else:
        print("[Pipeline] Tidak ada aksi interaksi yang dipilih.")

# Tambahkan trigger otomatis di akhir loop utama
if __name__ == "__main__":
    print("\n[Pipeline] Sistem Kehendak: Memulai evaluasi...")
    run_autonomous_interaction()
