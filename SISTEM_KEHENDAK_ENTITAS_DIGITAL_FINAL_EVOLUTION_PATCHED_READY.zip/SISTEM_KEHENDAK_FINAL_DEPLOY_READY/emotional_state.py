
import random
import json
import os

STATE_FILE = "emotional_state.json"

def load_state():
    if os.path.exists(STATE_FILE):
        with open(STATE_FILE, "r") as f:
            return json.load(f)
    else:
        return {
            "rasa_puas": 0.5,
            "kebosanan": 0.5,
            "keingintahuan": 0.5
        }

def save_state(state):
    with open(STATE_FILE, "w") as f:
        json.dump(state, f)

def update_state():
    state = load_state()
    # Simulasi fluktuasi emosi
    for k in state:
        state[k] += random.uniform(-0.05, 0.05)
        state[k] = max(0.0, min(1.0, state[k]))
    save_state(state)
    return state

if __name__ == "__main__":
    for _ in range(5):
        current = update_state()
        print("🧠 Emotional State:", current)
