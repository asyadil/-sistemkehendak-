
import json
import os

MEMORY_FILE = "world_memory.json"

def simpan_status(data):
    with open(MEMORY_FILE, "w") as f:
        json.dump(data, f)
    print("💾 Status disimpan ke world_memory.json")

def muat_status():
    if not os.path.exists(MEMORY_FILE):
        return {}
    with open(MEMORY_FILE, "r") as f:
        return json.load(f)
