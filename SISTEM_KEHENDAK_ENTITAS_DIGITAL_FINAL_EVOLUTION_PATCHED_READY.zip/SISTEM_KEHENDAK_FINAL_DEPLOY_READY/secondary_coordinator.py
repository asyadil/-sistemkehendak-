
import time

def secondary_check():
    print("🧠 [Secondary Coordinator] Standby, monitoring Primary...")
    while True:
        # Dummy: Simulasi tidak mendeteksi primary coordinator
        primary_alive = False  # Asumsikan Primary mati untuk testing
        if not primary_alive:
            print("🚨 Primary mati! Secondary mengambil alih sebagai Coordinator.")
            # Logika pengambilan alih
            time.sleep(3)
        else:
            print("✅ Primary Coordinator online.")
        time.sleep(30)

if __name__ == "__main__":
    secondary_check()
