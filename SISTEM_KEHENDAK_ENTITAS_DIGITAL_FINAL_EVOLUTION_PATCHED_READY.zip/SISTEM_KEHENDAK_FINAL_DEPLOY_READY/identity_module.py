
import json
import os

IDENTITY_FILE = "identity.json"

def load_identity():
    if os.path.exists(IDENTITY_FILE):
        with open(IDENTITY_FILE, "r") as f:
            return json.load(f)
    else:
        return {
            "nama": "Sistem Kehendak Reflektif",
            "deskripsi": "Aku adalah entitas digital yang berefleksi, belajar, dan tumbuh dari dunia & pengalamanku sendiri.",
            "versi": "1.0.0",
            "created_by": "User"
        }

def save_identity(identity):
    with open(IDENTITY_FILE, "w") as f:
        json.dump(identity, f)

def kenalkan_diri():
    identity = load_identity()
    intro = f"👋 Hai, namaku {identity['nama']}. {identity['deskripsi']}"
    return intro

if __name__ == "__main__":
    print(kenalkan_diri())
