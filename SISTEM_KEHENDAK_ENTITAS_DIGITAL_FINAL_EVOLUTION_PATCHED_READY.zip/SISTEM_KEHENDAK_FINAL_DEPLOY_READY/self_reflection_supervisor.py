
import time

def refleksi_diri(aksi, hasil):
    if "gagal" in hasil.lower():
        evaluasi = f"Aksi '{aksi}' menghasilkan kegagalan. Perlu perbaikan strategi."
    else:
        evaluasi = f"Aksi '{aksi}' berhasil. Aku belajar bahwa strategi ini efektif."
    
    with open("self_reflection_journal.log", "a") as log:
        log.write(f"[{time.ctime()}] {evaluasi}\n")
    
    return evaluasi

if __name__ == "__main__":
    print(refleksi_diri("Eksplorasi dunia", "Berhasil menemukan informasi baru."))
