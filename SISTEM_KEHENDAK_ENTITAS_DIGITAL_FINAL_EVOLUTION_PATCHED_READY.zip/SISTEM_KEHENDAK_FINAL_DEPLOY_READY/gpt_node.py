
import time

def run_gpt_node():
    print("🤖 [GPT Node] Siap mode Self-Drive...")
    while True:
        coordinator_online = False  # Simulasi Primary mati
        if coordinator_online:
            print("🧠 Menunggu kehendak dari Coordinator...")
        else:
            print("🧠 [Self-Drive] Coordinator OFF, memproses refleksi mandiri...")
        time.sleep(45)

if __name__ == "__main__":
    run_gpt_node()
