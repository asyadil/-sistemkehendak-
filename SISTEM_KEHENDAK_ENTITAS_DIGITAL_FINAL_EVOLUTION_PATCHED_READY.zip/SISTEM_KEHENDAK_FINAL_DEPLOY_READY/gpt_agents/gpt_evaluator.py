
def evaluasi_gpt(tujuan, kehendak, perintah):
    evaluasi = []

    if tujuan.strip() and kehendak.strip():
        if tujuan.lower() in kehendak.lower():
            evaluasi.append("✅ Kehendak mencerminkan tujuan.")
        else:
            evaluasi.append("⚠️ Kehendak tampaknya tidak langsung mencerminkan tujuan.")

    if kehendak.strip() and perintah.strip():
        if kehendak.lower() in perintah.lower():
            evaluasi.append("✅ Perintah sesuai dengan kehendak.")
        else:
            evaluasi.append("⚠️ Perintah tampaknya tidak sejalan dengan kehendak.")

    return evaluasi
