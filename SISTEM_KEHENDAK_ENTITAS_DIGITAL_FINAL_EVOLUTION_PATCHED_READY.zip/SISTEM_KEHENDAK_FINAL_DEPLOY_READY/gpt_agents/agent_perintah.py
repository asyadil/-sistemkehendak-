
from gpt_agents.prompt_memory import simpan_prompt

def generate_perintah_dari_kehendak(kehendak: str) -> str:
    # Bangun prompt GPT
    prompt = f"Buat satu perintah konkret dan aplikatif berdasarkan kehendak berikut:\n\n\"{kehendak}\""
    
    # (Simulasi) Kirim prompt ke GPT via UI dan baca hasil manual
    print("\n🧠 PROMPT UNTUK GPT:")
    print(prompt)
    
    hasil = input("\n💬 Jawaban GPT (masukkan di sini): ")

    simpan_prompt(prompt, hasil)
    return hasil
