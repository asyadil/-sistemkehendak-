
def rekomendasi_tindakan(perintah):
    rekomendasi = []
    perintah = perintah.lower()
    if "logika" in perintah and "ubah" in perintah:
        rekomendasi.append("🔧 Disarankan memanggil trigger_self_edit() untuk memodifikasi modul handler.")
    if "percepat" in perintah:
        rekomendasi.append("💡 Coba optimalkan pipeline_handler.py atau tambahkan cache sederhana.")
    if "simulasikan" in perintah:
        rekomendasi.append("🌍 Jalankan world_perception untuk input otomatis dari dunia.")
    return rekomendasi
