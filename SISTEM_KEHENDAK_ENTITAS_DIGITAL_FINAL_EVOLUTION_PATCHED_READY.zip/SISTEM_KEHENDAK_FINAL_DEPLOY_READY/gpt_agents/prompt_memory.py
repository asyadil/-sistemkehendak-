
import json, os
PROMPT_MEMORI_FILE = "memory/prompt_memory.jsonl"

def simpan_prompt(prompt, hasil):
    data = {
        "prompt": prompt,
        "hasil": hasil
    }
    os.makedirs("memory", exist_ok=True)
    with open(PROMPT_MEMORI_FILE, "a") as f:
        f.write(json.dumps(data) + "\n")

def ambil_prompt_terakhir(n=3):
    try:
        with open(PROMPT_MEMORI_FILE", "r") as f:
            lines = f.readlines()[-n:]
            return [json.loads(line) for line in lines]
    except:
        return []
