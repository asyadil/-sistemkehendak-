
from gpt_agents.gpt_evaluator import evaluasi_gpt
from handler.pipeline_handler import proses_input

def jalankan_loop_refleksi_dengan_evaluasi(input_user):
    hasil = proses_input(input_user)
    hasil_evaluasi = evaluasi_gpt(hasil['tujuan'], hasil['kehendak'], hasil['perintah'])
    hasil['evaluasi_gpt'] = hasil_evaluasi
    return hasil
