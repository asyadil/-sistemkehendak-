
import time
import json
import os

def check_drive_memory():
    if os.path.exists("world_memory.json"):
        with open("world_memory.json") as f:
            data = json.load(f)
        print(f"💾 [Tiny Agent] Memory terakhir dari Drive: {data}")
    else:
        print("❌ [Tiny Agent] Tidak ada world_memory.json ditemukan!")

def loop():
    while True:
        check_drive_memory()
        time.sleep(60)  # cek tiap 1 menit

if __name__ == "__main__":
    loop()
