from sistem_kehendak.adapter.telegram_adapter import mulai_adapter_telegram as start_bot

if __name__ == "__main__":
    print("🤖 Telegram Bot aktif... menunggu pesan.")
    start_bot()