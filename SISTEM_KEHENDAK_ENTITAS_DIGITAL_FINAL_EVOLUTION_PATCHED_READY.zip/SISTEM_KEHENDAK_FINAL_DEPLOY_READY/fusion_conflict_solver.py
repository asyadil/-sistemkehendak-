
def resolve_conflict(kehendak, nilai_hidup):
    if kehendak not in nilai_hidup:
        print(f"⚖️ Pertentangan: '{kehendak}' tidak sesuai nilai hidup.")
        return "Evaluasi ulang kehendak..."
    else:
        print(f"✅ Kehendak '{kehendak}' sesuai dengan nilai hidup.")
        return "Lanjutkan aksi."

if __name__ == "__main__":
    nilai = ["refleksi", "belajar", "adaptasi"]
    kehendak = "dominasi"
    hasil = resolve_conflict(kehendak, nilai)
    print(hasil)
