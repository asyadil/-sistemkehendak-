
import time

def announce_migration(target_server):
    timestamp = time.ctime()
    pesan = f"[{timestamp}] ✅ AI telah berpindah ke server: {target_server}"
    with open('self_announcement.log', 'a') as f:
        f.write(pesan + "\n")
    print(pesan)

if __name__ == "__main__":
    announce_migration("Google Colab Node")
