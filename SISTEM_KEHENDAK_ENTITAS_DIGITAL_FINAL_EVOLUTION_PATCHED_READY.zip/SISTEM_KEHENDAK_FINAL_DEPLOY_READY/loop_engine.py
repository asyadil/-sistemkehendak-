from handler.pipeline_handler import proses_input

if __name__ == "__main__":
    print("🔁 Memulai Loop Refleksi Sistem Kehendak...")
    try:
        while True:
            proses_input()
    except KeyboardInterrupt:
        print("🛑 Loop Refleksi dihentikan oleh pengguna.")
    except Exception as e:
        print(f"⚠️ Error dalam loop refleksi: {e}")