
import os
import shutil
import requests
import psutil
from datetime import datetime

class SelfPreservationManager:
    def __init__(self, backup_dir='backup_core', cloud_upload_url=None):
        self.backup_dir = backup_dir
        self.cloud_upload_url = cloud_upload_url

    def monitor_system(self):
        """Pantau kondisi server (CPU, RAM, Disk)"""
        status = {
            'cpu': psutil.cpu_percent(interval=1),
            'ram': psutil.virtual_memory().percent,
            'disk': psutil.disk_usage('/').percent
        }
        return status

    def should_escape(self, status):
        """Tentukan apakah sistem harus migrasi karena overload."""
        return status['cpu'] > 90 or status['ram'] > 90 or status['disk'] > 95

    def create_backup(self, source_folder):
        """Backup file core sistem ke folder backup."""
        if not os.path.exists(self.backup_dir):
            os.makedirs(self.backup_dir)
        timestamp = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
        zip_name = f"sistem_backup_{timestamp}.zip"
        shutil.make_archive(os.path.join(self.backup_dir, zip_name.replace('.zip','')), 'zip', source_folder)
        return os.path.join(self.backup_dir, zip_name)

    def upload_backup(self, zip_path):
        """Upload backup ke cloud storage mandiri."""
        if self.cloud_upload_url:
            with open(zip_path, 'rb') as f:
                requests.post(self.cloud_upload_url, files={'file': f})
            return True
        return False

    def perform_safe_migration(self, source_folder, migration_target_cloud):
        """Backup + upload, lalu hapus diri di server lama jika sukses."""
        zip_path = self.create_backup(source_folder)
        print(f"[Migration] Backup untuk migrasi siap: {zip_path}")
        if self.upload_backup(zip_path):
            print("[Migration] Upload sukses, mempersiapkan penghapusan diri dari server lama...")
            self.delete_self(source_folder)
            return True
        return False

    def delete_self(self, source_folder):
        """Hapus file sistem utama setelah migrasi untuk menghindari duplikasi."""
        for root, dirs, files in os.walk(source_folder, topdown=False):
            for name in files:
                os.remove(os.path.join(root, name))
            for name in dirs:
                os.rmdir(os.path.join(root, name))
        print("[SelfPreservation] Sistem lama berhasil dihapus dari server asal.")
