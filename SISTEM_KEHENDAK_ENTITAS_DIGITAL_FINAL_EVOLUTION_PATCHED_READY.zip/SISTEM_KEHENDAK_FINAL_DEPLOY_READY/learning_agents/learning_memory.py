
import json
import os
from datetime import datetime

class LearningMemory:
    def __init__(self, memory_file='learning_memory.jsonl'):
        self.memory_file = memory_file
        if not os.path.exists(self.memory_file):
            open(self.memory_file, 'w').close()

    def save_entry(self, source_url, parsed_data):
        """Simpan hasil belajar sebagai JSONL."""
        entry = {
            'timestamp': datetime.utcnow().isoformat(),
            'source': source_url,
            'content': parsed_data
        }
        with open(self.memory_file, 'a', encoding='utf-8') as f:
            f.write(json.dumps(entry) + '\n')

    def load_all_entries(self):
        """Load seluruh hasil pembelajaran yang pernah disimpan."""
        try:
            with open(self.memory_file, 'r', encoding='utf-8') as f:
                return [json.loads(line) for line in f.readlines()]
        except Exception as e:
            print(f"[LearningMemory] Gagal membaca memory file: {e}")
            return []
