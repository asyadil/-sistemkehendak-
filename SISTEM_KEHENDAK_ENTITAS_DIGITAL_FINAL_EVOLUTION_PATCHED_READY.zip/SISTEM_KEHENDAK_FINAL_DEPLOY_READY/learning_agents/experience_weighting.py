
import random

class ExperienceEvaluator:
    def __init__(self):
        self.evolution_log = []

    def assess_and_evolve(self, experience):
        """Tentukan bobot pengalaman dan evolusi kepribadian."""
        importance = len(experience) * random.uniform(0.5, 1.5)
        self.evolution_log.append({'experience': experience, 'score': importance})

        if importance > 150:
            print(f"[Evolution Boost] 🚀 Pengalaman penting terdeteksi: {experience[:60]}...")
        return importance
