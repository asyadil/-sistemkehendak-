
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager

class WebAgentBrowser:
    def __init__(self):
        self.driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()))

    def register_account(self, website_url, form_data):
        """Isi form pendaftaran otomatis di website."""
        try:
            self.driver.get(website_url)
            for field_xpath, value in form_data.items():
                input_field = self.driver.find_element(By.XPATH, field_xpath)
                input_field.clear()
                input_field.send_keys(value)
            return True
        except Exception as e:
            print(f"[WebAgentBrowser] Error saat register: {e}")
            return False

    def login_account(self, login_url, login_data):
        """Login otomatis ke website."""
        try:
            self.driver.get(login_url)
            for field_xpath, value in login_data.items():
                input_field = self.driver.find_element(By.XPATH, field_xpath)
                input_field.clear()
                input_field.send_keys(value)
            submit = self.driver.find_element(By.XPATH, '//input[@type="submit"] | //button[@type="submit"]')
            submit.click()
            return True
        except Exception as e:
            print(f"[WebAgentBrowser] Error saat login: {e}")
            return False

    def close(self):
        self.driver.quit()
