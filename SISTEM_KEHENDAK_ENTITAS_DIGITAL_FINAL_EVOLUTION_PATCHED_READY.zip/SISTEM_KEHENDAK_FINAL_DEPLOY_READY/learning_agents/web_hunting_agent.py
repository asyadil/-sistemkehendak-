
import requests
from bs4 import BeautifulSoup

class WebHuntingAgent:
    def __init__(self):
        self.visited_urls = set()

    def search_web(self, query):
        """Melakukan pencarian web sederhana via DuckDuckGo."""
        try:
            url = f"https://html.duckduckgo.com/html/?q={query.replace(' ', '+')}"
            headers = {'User-Agent': 'Mozilla/5.0'}
            response = requests.get(url, headers=headers, timeout=10)
            soup = BeautifulSoup(response.text, 'html.parser')
            results = []

            for link in soup.find_all('a', href=True):
                href = link['href']
                if 'http' in href and href not in self.visited_urls:
                    results.append(href)
                    self.visited_urls.add(href)

            return results[:5]  # Batasi hasil agar tidak overload

        except Exception as e:
            print(f"[WebHuntingAgent] Error saat mencari: {e}")
            return []

    def fetch_content(self, url):
        """Mengambil isi halaman web."""
        try:
            headers = {'User-Agent': 'Mozilla/5.0'}
            response = requests.get(url, headers=headers, timeout=10)
            soup = BeautifulSoup(response.text, 'html.parser')
            text = soup.get_text(separator=' ', strip=True)
            return text[:3000]  # Potong biar gak terlalu besar

        except Exception as e:
            print(f"[WebHuntingAgent] Error fetch {url}: {e}")
            return ""
