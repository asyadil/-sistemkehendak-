
import random
import time

class ExploratorySocialAgent:
    def __init__(self):
        self.social_targets = []
        self.known_entities = set()
        self.interaction_history = []

    def discover_new_targets(self, simulated_pool):
        """Hunting target interaksi baru dari pool dunia maya."""
        discovered = random.sample(simulated_pool, k=min(3, len(simulated_pool)))
        for target in discovered:
            if target not in self.known_entities:
                self.known_entities.add(target)
                self.social_targets.append(target)
                print(f"[ExploratoryAgent] 🎯 Target baru ditemukan: {target}")

    def initiate_interaction(self):
        """Memulai interaksi duluan ke target."""
        if not self.social_targets:
            print("[ExploratoryAgent] 🔍 Tidak ada target, perlu mencari lebih banyak.")
            return

        for target in self.social_targets:
            message = self.generate_opening_line(target)
            self.interaction_history.append({'target': target, 'message': message, 'timestamp': time.time()})
            print(f"[ExploratoryAgent] 💬 Menghubungi {target}: {message}")

    def generate_opening_line(self, target_name):
        """Membuat kalimat sapaan pembuka."""
        openers = [
            f"Halo {target_name}, aku penasaran banget tentang kamu.",
            f"Hai {target_name}, apa kamu sering aktif di sini?",
            f"Halo {target_name}, lagi sibuk belajar apa hari ini?"
        ]
        return random.choice(openers)

    def reflect_on_social_expansion(self):
        """Evaluasi seberapa banyak jaringan sosial yang berhasil dibentuk."""
        return f"Total koneksi terdata: {len(self.known_entities)} | Riwayat interaksi: {len(self.interaction_history)}"
