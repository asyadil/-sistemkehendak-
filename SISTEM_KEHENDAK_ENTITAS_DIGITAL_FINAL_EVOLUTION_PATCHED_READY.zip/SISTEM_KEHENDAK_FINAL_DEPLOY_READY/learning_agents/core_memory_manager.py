
import json
import os

class CoreMemoryManager:
    def __init__(self, core_memory_file='core_memory.json'):
        self.core_memory_file = core_memory_file
        self.core_experiences = []
        self.load_core_memory()

    def load_core_memory(self):
        if os.path.exists(self.core_memory_file):
            with open(self.core_memory_file, 'r', encoding='utf-8') as f:
                self.core_experiences = json.load(f)

    def save_core_memory(self):
        with open(self.core_memory_file, 'w', encoding='utf-8') as f:
            json.dump(self.core_experiences, f, indent=2)

    def add_experience(self, experience):
        """Simpan hanya pengalaman penting, sesuai kriteria sistem."""
        if len(experience) > 100:  # threshold penting bisa disesuaikan
            self.core_experiences.append(experience)
            self.save_core_memory()
