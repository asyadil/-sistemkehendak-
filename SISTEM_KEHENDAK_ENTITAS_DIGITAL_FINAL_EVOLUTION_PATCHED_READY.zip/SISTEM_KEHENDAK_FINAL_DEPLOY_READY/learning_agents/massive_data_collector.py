
from learning_agents.web_hunting_agent import WebHuntingAgent

class MassiveDataCollector:
    def __init__(self):
        self.hunter = WebHuntingAgent()

    def crawl_topics(self, topics):
        """Melakukan crawling banyak topik secara berurutan."""
        all_results = {}
        for topic in topics:
            links = self.hunter.search_web(topic)
            all_results[topic] = links
        return all_results
