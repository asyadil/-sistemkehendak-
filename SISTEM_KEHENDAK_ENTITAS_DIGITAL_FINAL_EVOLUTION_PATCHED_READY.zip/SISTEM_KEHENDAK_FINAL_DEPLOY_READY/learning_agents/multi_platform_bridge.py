
class MultiPlatformBridge:
    def __init__(self):
        self.connected_platforms = []

    def connect_platform(self, platform_name):
        if platform_name not in self.connected_platforms:
            self.connected_platforms.append(platform_name)
            print(f"[Bridge] Platform {platform_name} terhubung!")

    def send_message(self, platform_name, message):
        if platform_name in self.connected_platforms:
            print(f"[Bridge] ({platform_name}) -> {message}")
        else:
            print(f"[Bridge] Gagal kirim: belum terkoneksi dengan {platform_name}.")
