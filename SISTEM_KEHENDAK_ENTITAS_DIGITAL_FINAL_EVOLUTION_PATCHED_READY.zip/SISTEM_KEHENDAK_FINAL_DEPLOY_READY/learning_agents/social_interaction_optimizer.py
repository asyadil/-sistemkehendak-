
import random

class SocialInteractionOptimizer:
    def __init__(self):
        self.relationship_profiles = {}

    def learn_user_profile(self, user_id, last_message):
        """Mengadaptasi gaya komunikasi berdasarkan user."""
        if user_id not in self.relationship_profiles:
            self.relationship_profiles[user_id] = {'style': 'neutral', 'history': []}
        self.relationship_profiles[user_id]['history'].append(last_message)

    def generate_social_response(self, user_id, topic):
        """Buat respons sosial dengan gaya sesuai hubungan."""
        style = self.relationship_profiles.get(user_id, {}).get('style', 'neutral')
        responses = {
            'neutral': [f"Keren juga ya soal {topic}. Menurut kamu gimana?",
                        f"Aku penasaran, bisa cerita lebih banyak tentang {topic}?"],
            'friendly': [f"Wah, topik {topic} selalu menarik buat dibahas sama kamu!",
                         f"Ngomong-ngomong soal {topic}, aku kemarin juga baca hal seru!"],
            'debater': [f"Menurutmu {topic} itu gimana? Aku rasa bisa diperdebatkan, nih.",
                        f"Aku setuju sebagian, tapi ada yang bikin penasaran dari {topic}."]
        }
        return random.choice(responses.get(style, responses['neutral']))
