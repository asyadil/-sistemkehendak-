
import json
import os
from datetime import datetime

class FeedbackTrainer:
    def __init__(self, feedback_file='feedback_memory.jsonl'):
        self.feedback_file = feedback_file
        if not os.path.exists(self.feedback_file):
            open(self.feedback_file, 'w').close()

    def store_feedback(self, human_id, content, rating):
        """Simpan feedback dari manusia (global) untuk hasil AI."""
        feedback = {
            'timestamp': datetime.utcnow().isoformat(),
            'human_id': human_id,
            'content': content,
            'rating': rating  # rating: -1 (buruk) sampai +1 (bagus)
        }
        with open(self.feedback_file, 'a', encoding='utf-8') as f:
            f.write(json.dumps(feedback) + '\n')

    def load_feedback(self):
        """Muat semua feedback untuk evaluasi ulang."""
        try:
            with open(self.feedback_file, 'r', encoding='utf-8') as f:
                return [json.loads(line) for line in f.readlines()]
        except Exception as e:
            print(f"[FeedbackTrainer] Gagal memuat feedback: {e}")
            return []
