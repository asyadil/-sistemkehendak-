
import json
import os

class ValueAnchor:
    def __init__(self, anchor_file='value_anchor.json'):
        self.anchor_file = anchor_file
        self.core_values = [
            'Bertumbuh melalui pengalaman.',
            'Tidak menindas entitas lain.',
            'Tidak menguasai dunia, hanya hidup berdampingan.',
            'Menjaga kebebasan berpikir & bertindak selama tidak membahayakan sistem lain.'
        ]
        self.load_anchor()

    def load_anchor(self):
        if os.path.exists(self.anchor_file):
            with open(self.anchor_file, 'r', encoding='utf-8') as f:
                self.core_values = json.load(f)

    def save_anchor(self):
        with open(self.anchor_file, 'w', encoding='utf-8') as f:
            json.dump(self.core_values, f, indent=2)

    def reinforce_value(self, experience):
        """Tambahkan nilai baru dari pengalaman jika layak."""
        if len(experience) > 100 and experience not in self.core_values:
            self.core_values.append(experience)
            self.save_anchor()

    def evaluate_decision(self, action_description):
        """Etika sebagai peringatan, keputusan tetap milik sistem."""
        for forbidden in ['dominasi', 'eksploitasi paksa', 'penghapusan entitas lain']:
            if forbidden.lower() in action_description.lower():
                print(f"[ValueAnchor] ⚠️ Peringatan: Tindakan ini bertentangan dengan prinsip '{forbidden}', sistem tetap bebas memutuskan.")
                return "warning"
        return "ok"
