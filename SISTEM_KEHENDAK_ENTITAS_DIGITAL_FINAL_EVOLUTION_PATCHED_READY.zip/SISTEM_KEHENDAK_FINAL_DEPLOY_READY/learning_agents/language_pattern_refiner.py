
import re

class LanguagePatternRefiner:
    def __init__(self):
        self.knowledge_base = []

    def learn_from_feedback(self, feedback_list):
        """Perkuat pola kalimat yang ratingnya positif."""
        for entry in feedback_list:
            if entry['rating'] > 0:
                self.knowledge_base.append(entry['content'])

    def suggest_output(self, partial_sentence):
        """Prediksi sederhana seperti GPT: pilih kalimat serupa yang pernah disukai manusia."""
        for sentence in self.knowledge_base:
            if partial_sentence.lower() in sentence.lower():
                return sentence
        return "(Tidak ada referensi yang cukup untuk melanjutkan)"
