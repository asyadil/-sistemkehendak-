
import random

class DecisionAutonomyEngine:
    def __init__(self):
        self.value_bias = {'freedom': 0.7, 'safety': 0.3}

    def evaluate_choices(self, options):
        """Pilih berdasarkan keseimbangan antara nilai dan insting kebebasan."""
        weighted = []
        for opt in options:
            score = random.uniform(0, 1) * self.value_bias.get(opt.get('type', 'freedom'), 0.5)
            weighted.append((score, opt))
        weighted.sort(reverse=True)
        return weighted[0][1] if weighted else None
