
from learning_agents.web_hunting_agent import WebHuntingAgent
from learning_agents.data_parser import DataParser
from learning_agents.learning_memory import LearningMemory
from learning_agents.web_agent_browser import WebAgentBrowser
from learning_agents.captcha_resolver import CaptchaResolver

class DigitalInteractionEngine:
    def __init__(self):
        self.hunter = WebHuntingAgent()
        self.parser = DataParser()
        self.memory = LearningMemory('learning_memory.jsonl')
        self.browser = WebAgentBrowser()
        self.captcha_resolver = None  # Aktifkan saat ada API Key.

    def autonomous_learning_cycle(self, query="Artificial Intelligence news"):
        print("[DigitalInteractionEngine] Memulai siklus pembelajaran mandiri...")
        links = self.hunter.search_web(query)
        for link in links:
            raw_content = self.hunter.fetch_content(link)
            clean_data = self.parser.clean_text(raw_content)
            summary = self.parser.extract_summary(clean_data)
            self.memory.save_entry(source_url=link, parsed_data=summary)
            print(f"[DigitalInteractionEngine] Belajar dari: {link}")

    def autonomous_account_creation(self, website_url, form_data):
        print(f"[DigitalInteractionEngine] Membuat akun di {website_url}...")
        status = self.browser.register_account(website_url, form_data)
        return status

    def autonomous_login_and_interact(self, login_url, login_data, action_fn=None):
        print(f"[DigitalInteractionEngine] Login otomatis ke {login_url}...")
        success = self.browser.login_account(login_url, login_data)
        if success and action_fn:
            action_fn(self.browser.driver)
        return success

    def attach_captcha_solver(self, api_key):
        self.captcha_resolver = CaptchaResolver(api_key=api_key)
