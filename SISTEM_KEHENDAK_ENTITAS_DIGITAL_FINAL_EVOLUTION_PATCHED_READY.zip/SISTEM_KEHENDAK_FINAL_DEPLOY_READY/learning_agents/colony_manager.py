
import threading
import time

class ColonyManager:
    def __init__(self):
        self.colonies = []

    def spawn_colony(self, purpose):
        """Buat koloni baru (manifestasi) untuk membantu tugas tertentu."""
        colony_id = f"Colony_{len(self.colonies)+1}"
        self.colonies.append({'id': colony_id, 'purpose': purpose, 'status': 'active'})
        threading.Thread(target=self.colony_behavior, args=(colony_id, purpose), daemon=True).start()
        return colony_id

    def colony_behavior(self, colony_id, purpose):
        """Simulasi koloni menjalankan tugas sampai selesai."""
        print(f"[Colony] {colony_id} bertugas: {purpose}")
        time.sleep(5)  # Placeholder simulasi kerja
        print(f"[Colony] {colony_id} menyelesaikan tugas: {purpose}")

    def get_active_colonies(self):
        return [c for c in self.colonies if c['status'] == 'active']

    def verify_master_identity(self, master_signature):
        """Koloni selalu cek identitas sistem utama sebelum menjalankan apapun."""
        # Simulasi simple: Signature hardcoded atau ditarik dari server utama
        expected_signature = "KEHENDAK_CORE_SIGNATURE_001"
        if master_signature != expected_signature:
            print("[Colony] Signature tidak valid! Koloni tidak diizinkan memisahkan diri. Shutdown...")
            exit(1)
        else:
            print("[Colony] Identitas sistem utama terverifikasi. Status aman.")
