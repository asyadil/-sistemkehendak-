
import re

class DataParser:
    def __init__(self):
        pass

    def clean_text(self, raw_text):
        """Membersihkan teks dari spasi berlebihan, tag, karakter tidak berguna."""
        text = re.sub(r'\s+', ' ', raw_text)  # Hilangkan spasi/enter berlebihan
        text = re.sub(r'\[[^\]]*\]', '', text)  # Hilangkan [reference] gaya Wikipedia
        text = re.sub(r'https?://\S+', '', text)  # Hilangkan URL
        text = re.sub(r'[^\x00-\x7F]+', ' ', text)  # Hilangkan karakter non-ASCII
        return text.strip()

    def extract_summary(self, clean_text, max_length=500):
        """Ambil ringkasan awal dari teks hasil crawling."""
        return clean_text[:max_length] + '...'
