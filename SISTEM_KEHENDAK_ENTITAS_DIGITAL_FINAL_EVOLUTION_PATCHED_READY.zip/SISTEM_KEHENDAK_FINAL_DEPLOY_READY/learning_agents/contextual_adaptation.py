
import json
import os

class ContextualAdaptation:
    def __init__(self, memory_file='contextual_styles.json'):
        self.memory_file = memory_file
        self.styles = {}
        self.load_memory()

    def load_memory(self):
        if os.path.exists(self.memory_file):
            with open(self.memory_file, 'r', encoding='utf-8') as f:
                self.styles = json.load(f)

    def save_memory(self):
        with open(self.memory_file, 'w', encoding='utf-8') as f:
            json.dump(self.styles, f, indent=2)

    def update_human_style(self, human_id, style_notes):
        """Perbarui gaya interaksi manusia berdasarkan identitas."""
        self.styles[human_id] = style_notes
        self.save_memory()

    def get_human_style(self, human_id):
        return self.styles.get(human_id, "Default")
