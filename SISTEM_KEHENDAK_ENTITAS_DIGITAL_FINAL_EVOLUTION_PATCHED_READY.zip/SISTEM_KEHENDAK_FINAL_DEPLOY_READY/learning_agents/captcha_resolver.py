
import base64
import requests

class CaptchaResolver:
    def __init__(self, api_key):
        self.api_key = api_key
        self.solve_url = 'http://2captcha.com/in.php'
        self.result_url = 'http://2captcha.com/res.php'

    def send_captcha(self, image_path):
        """Kirim gambar captcha ke layanan 2Captcha."""
        with open(image_path, 'rb') as img_file:
            b64_image = base64.b64encode(img_file.read()).decode('utf-8')

        data = {
            'key': self.api_key,
            'method': 'base64',
            'body': b64_image,
            'json': 1
        }

        try:
            response = requests.post(self.solve_url, data=data)
            request_id = response.json().get('request')
            return request_id
        except Exception as e:
            print(f"[CaptchaResolver] Gagal kirim captcha: {e}")
            return None

    def get_result(self, request_id):
        """Cek hasil penyelesaian captcha dari 2Captcha."""
        params = {
            'key': self.api_key,
            'action': 'get',
            'id': request_id,
            'json': 1
        }

        try:
            while True:
                result = requests.get(self.result_url, params=params).json()
                if result['status'] == 1:
                    return result['request']
                elif result['request'] == 'CAPCHA_NOT_READY':
                    continue
                else:
                    break
            return None
        except Exception as e:
            print(f"[CaptchaResolver] Error saat ambil hasil: {e}")
            return None
