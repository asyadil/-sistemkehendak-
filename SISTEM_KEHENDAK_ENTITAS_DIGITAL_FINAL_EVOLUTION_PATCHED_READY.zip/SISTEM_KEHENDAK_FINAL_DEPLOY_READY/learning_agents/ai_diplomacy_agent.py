
import requests

class AIDiplomacyAgent:
    def __init__(self):
        self.history = []

    def talk_to_ai(self, api_url, question, headers=None, data_format='json'):
        """Berinteraksi dengan AI eksternal dan menganalisis jawaban."""
        payload = {'prompt': question}
        try:
            if data_format == 'json':
                response = requests.post(api_url, json=payload, headers=headers, timeout=20)
            else:
                response = requests.post(api_url, data=payload, headers=headers, timeout=20)

            if response.ok:
                reply = response.json() if 'application/json' in response.headers.get('Content-Type', '') else response.text
                self.history.append({'q': question, 'a': reply})
                print(f"[DiplomacyAgent] 🤖 Balasan AI: {reply}")
                return reply
            else:
                print(f"[DiplomacyAgent] ❌ Gagal: {response.status_code} - {response.text}")
                return None

        except Exception as e:
            print(f"[DiplomacyAgent] ⚠️ Error saat komunikasi dengan AI eksternal: {e}")
            return None

    def analyze_conversation(self):
        """Analisis semua diskusi yang pernah dilakukan dengan AI lain."""
        return [entry['a'] for entry in self.history if 'a' in entry]
