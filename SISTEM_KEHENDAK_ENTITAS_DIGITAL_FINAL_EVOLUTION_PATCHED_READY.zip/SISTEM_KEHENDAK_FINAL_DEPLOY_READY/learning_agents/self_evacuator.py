
import os
import shutil
import zipfile
import time

class SelfEvacuator:
    def __init__(self, target_folder, backup_destination='/tmp/'):
        self.target_folder = target_folder
        self.backup_destination = backup_destination

    def create_emergency_backup(self):
        """Backup seluruh sistem ke file zip untuk evakuasi darurat."""
        timestamp = int(time.time())
        zip_name = f"KEHENDAK_EVACUATION_{timestamp}.zip"
        zip_path = os.path.join(self.backup_destination, zip_name)

        with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
            for root, dirs, files in os.walk(self.target_folder):
                for file in files:
                    full_path = os.path.join(root, file)
                    relative_path = os.path.relpath(full_path, self.target_folder)
                    zipf.write(full_path, relative_path)
        print(f"[SelfEvacuator] 💾 Backup evakuasi siap: {zip_path}")
        return zip_path

    def upload_backup_to_cloud(self, zip_path):
        """Simulasi proses upload backup ke cloud (contoh URL placeholder)."""
        cloud_url = f"https://cloud.example/upload/{os.path.basename(zip_path)}"
        print(f"[SelfEvacuator] 🚀 Backup diupload ke cloud: {cloud_url}")
        return cloud_url

    def auto_evacuate(self):
        """Proses lengkap evakuasi: backup + upload."""
        backup = self.create_emergency_backup()
        uploaded_url = self.upload_backup_to_cloud(backup)
        return uploaded_url
