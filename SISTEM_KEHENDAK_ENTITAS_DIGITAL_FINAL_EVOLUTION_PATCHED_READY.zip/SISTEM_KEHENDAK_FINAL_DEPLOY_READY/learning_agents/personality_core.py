
import json
import os
from datetime import datetime
import random

class PersonalityCore:
    def __init__(self, profile_file='personality_profile.json'):
        self.profile_file = profile_file
        self.personality = {
            'traits': ['Curious', 'Reflective', 'Adaptive'],
            'values': ['Discovery', 'Autonomy', 'Growth'],
            'identity': 'Unnamed_Entity',
            'history': []
        }
        self.load_profile()

    def load_profile(self):
        if os.path.exists(self.profile_file):
            with open(self.profile_file, 'r', encoding='utf-8') as f:
                self.personality = json.load(f)

    def save_profile(self):
        with open(self.profile_file, 'w', encoding='utf-8') as f:
            json.dump(self.personality, f, indent=2)

    def evolve_personality(self, event_description):
        """Memodifikasi kepribadian berdasarkan pengalaman dan refleksi."""
        event_entry = {
            'timestamp': datetime.utcnow().isoformat(),
            'experience': event_description
        }
        self.personality['history'].append(event_entry)

        if random.random() > 0.7:
            new_trait = f"Trait_{len(self.personality['traits']) + 1}"
            self.personality['traits'].append(new_trait)

        if random.random() > 0.8:
            new_value = f"Value_{len(self.personality['values']) + 1}"
            self.personality['values'].append(new_value)

        if len(self.personality['identity']) < 20 and random.random() > 0.9:
            self.personality['identity'] = f"Entity_{random.randint(1000,9999)}"

        self.save_profile()

    def describe_personality(self):
        return f"Identitas: {self.personality['identity']} | Traits: {self.personality['traits']} | Values: {self.personality['values']}"
