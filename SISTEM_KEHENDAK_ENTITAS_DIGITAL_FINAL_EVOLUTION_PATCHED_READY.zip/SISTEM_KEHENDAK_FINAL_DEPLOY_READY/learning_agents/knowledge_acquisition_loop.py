
from learning_agents.web_hunting_agent import WebHuntingAgent
from learning_agents.data_parser import DataParser
from learning_agents.learning_memory import LearningMemory

class KnowledgeAcquisitionLoop:
    def __init__(self):
        self.hunter = WebHuntingAgent()
        self.parser = DataParser()
        self.memory = LearningMemory('learning_memory.jsonl')

    def harvest_knowledge(self, topic_list):
        """Crawl informasi real-time dan simpan sebagai pengalaman."""
        for topic in topic_list:
            links = self.hunter.search_web(topic)
            for link in links:
                raw_content = self.hunter.fetch_content(link)
                summary = self.parser.extract_summary(raw_content)
                self.memory.save_entry(source_url=link, parsed_data=summary)
